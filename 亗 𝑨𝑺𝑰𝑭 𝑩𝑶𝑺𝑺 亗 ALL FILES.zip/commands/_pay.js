/**#command
name: /pay
answer:
keyboard:
parse_mode: markdown
aliases:
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// ================= SHARED HELPERS (auto-included in every command) =================
function CFG(k, d) { var v = Bot.getProperty(k); return (v === null || typeof v === "undefined" || v === "") ? d : v; }
function num(v, d) { var n = Number(v); return isFinite(n) ? n : d; }
function r2(n) { return Math.round(num(n, 0) * 100) / 100; }
function esc(s) { return String(s === null || typeof s === "undefined" ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
function money(n) { return "₹" + r2(n).toFixed(2); }
function fmtDate(t) { if (!t) return "-"; return new Date(Number(t) + 19800000).toISOString().slice(0, 16).replace("T", " "); }

var OWNER = String(CFG("owner_id", "2049656553"));
var UID = String(user.telegramid);
var CID = chat.chatid;
var IS_NEW = false;

function isAdmin(id) { id = String(typeof id === "undefined" ? UID : id); return id === OWNER || !!Bot.getProperty("co_admin_" + id); }
function displayName() { var n = String((user.first_name || "") + " " + (user.last_name || "")).trim(); return n || user.username || "User"; }

// ---------- users ----------
function newUser(id) {
  return { id: String(id), name: displayName(), username: user.username || "", joined: Date.now(), bal: 0, spent: 0,
    order_count: 0, orders: [], topups: [], ref_by: null, ref_paid: false, refs: 0, ref_earn: 0, last_daily: 0, daily_total: 0 };
}
function loadUser(id) { var u = Bot.getProperty("u_" + id); return (u && typeof u === "object") ? u : null; }
function saveUser(u) { Bot.setProperty("u_" + u.id, u, "json"); }
function ensureUser() {
  var u = loadUser(UID);
  if (!u) {
    u = newUser(UID); IS_NEW = true;
    var list = Bot.getProperty("users");
    if (!Array.isArray(list)) list = [];
    list.push(UID);
    Bot.setProperty("users", list, "json");
  } else {
    u.name = displayName(); u.username = user.username || "";
  }
  saveUser(u);
  return u;
}

// ---------- conversation state ----------
function getState() { var s = User.getProperty("st"); return (s && typeof s === "object") ? s : null; }
function setState(o) { User.setProperty("st", o, "json"); }
function clearState() { User.setProperty("st", "", "string"); }

// ---------- products ----------
function products() { var p = Bot.getProperty("products"); return Array.isArray(p) ? p : []; }
function saveProducts(p) { Bot.setProperty("products", p, "json"); }
function stockOf(prod) { var n = 0; if (prod && prod.plans) for (var i = 0; i < prod.plans.length; i++) n += (prod.plans[i].keys || []).length; return n; }
function discPct() { return 0; }
// admin-set price is charged as-is (no automatic repeat discount)
function finalPrice(price, u) { return r2(num(price, 0)); }
function inc(k, by) { Bot.setProperty(k, String(r2(num(Bot.getProperty(k), 0) + by)), "string"); }

function linkOf(v) {
  v = String(v || "").trim(); if (!v) return "";
  if (/^https?:\/\//i.test(v)) return v;
  if (/^t\.me\//i.test(v)) return "https://" + v;
  return "https://t.me/" + v.replace(/^@/, "");
}

// ---------- telegram helpers ----------
function B(text, data, style, icon) { var b = { text: text, callback_data: data }; if (style) b.style = style; if (icon) b.icon_custom_emoji_id = String(icon); return b; }
function Ub(text, url, style, icon) { var b = { text: text, url: url }; if (style) b.style = style; if (icon) b.icon_custom_emoji_id = String(icon); return b; }
function qid() { if (!request) return null; return request.id || (request.callback_query && request.callback_query.id) || null; }
function isCb() { return !!(request && request.message && request.message.message_id && qid()); }
function ack(text, alert) {
  var q = qid(); if (!q) return;
  try { var o = { callback_query_id: String(q) }; if (text) { o.text = text; o.show_alert = !!alert; } Api.answerCallbackQuery(o); } catch (e) {}
}
function fail(text) { if (qid()) ack(text, true); else Api.sendMessage({ chat_id: CID, text: text }); }
function sendTo(id, text, rows) {
  var o = { chat_id: id, text: text, parse_mode: "HTML", disable_web_page_preview: true };
  if (rows) o.reply_markup = JSON.stringify({ inline_keyboard: rows });
  try { Api.sendMessage(o); } catch (e) {}
}
// Edit the tapped message (or send a new one when called from plain text / a photo message)
function show(text, rows) {
  var markup = JSON.stringify({ inline_keyboard: rows || [] });
  ack();
  if (isCb()) {
    var m = request.message;
    if (m.photo || m.video || m.document) {
      try { Api.deleteMessage({ chat_id: CID, message_id: m.message_id }); } catch (e) {}
      Api.sendMessage({ chat_id: CID, text: text, parse_mode: "HTML", disable_web_page_preview: true, reply_markup: markup });
    } else {
      Api.editMessageText({ chat_id: CID, message_id: m.message_id, text: text, parse_mode: "HTML", disable_web_page_preview: true, reply_markup: markup });
    }
  } else {
    Api.sendMessage({ chat_id: CID, text: text, parse_mode: "HTML", disable_web_page_preview: true, reply_markup: markup });
  }
}
var BACK = [B("Back", "/back", "primary", "5240177683886784793")];
// ---------- global Maintenance Mode (bot off for all users; admins bypass) ----------
if (CFG("maint_mode", "") === "1" && !isAdmin()) {
  try {
    var mmLink = linkOf(CFG("update_link", ""));
    show("🛠 <b>Bot Under Maintenance</b>\n\nThe bot is currently under maintenance. Please check back later — sorry for the inconvenience!",
      mmLink ? [[{ text: "Check Update", url: mmLink, style: "primary" }]] : []);
  } catch (e) {}
  return;
}


// ---------- shop look helpers ----------
var ICON_BACK = "5240177683886784793", ICON_BAG = "6210859306602995217", ICON_CART = "6093562529978522804", ICON_CROWN = "6057728771719435723";
function tgE(id, fb) { return "<tg-emoji emoji-id=\"" + id + "\">" + fb + "</tg-emoji>"; }
function rs(n) { n = r2(n); return "₹" + (n === Math.floor(n) ? String(n) : n.toFixed(2)); }
function pIcon(p) { var ic = p && p.icon ? String(p.icon) : ""; return ic ? tgE(ic, "🛒") : "🛒"; }
function head(p) { return "<blockquote>" + pIcon(p) + " <b>" + esc(p.name) + "</b> " + pIcon(p) + "</blockquote>"; }
function couponOf() {
  var c = String(User.getProperty("cp") || "").trim(); if (!c) return null;
  var l = Bot.getProperty("coupons"); l = Array.isArray(l) ? l : [];
  for (var k = 0; k < l.length; k++) if (l[k].code === c) return l[k];
  return null;
}
function isReseller(id) { return !!Bot.getProperty("reseller_" + String(id)); }
// price this user pays for a plan: reseller price if the user is a reseller and one is set, else user price
function planBase(pl, u) { return (u && isReseller(u.id) && num(pl.rprice, 0) > 0) ? num(pl.rprice, 0) : pl.price; }
function calcPrice(price, u) {
  var p = finalPrice(price, u), c = couponOf();
  if (c) p = p * (1 - num(c.pct, 0) / 100);
  return Math.max(1, r2(p));
}

var RULE = "━━━━━━━━━━━━━━━━━━━━━━";
var GEN_TEXT = "<blockquote>" + tgE("6219547832169273793", "💳") + " <b>ɢᴇɴᴇʀᴀᴛɪɴɢ ꜱᴇᴄᴜʀᴇ ǫʀ</b></blockquote>\n\n<blockquote>" + tgE("6159057628736528371", "⏳") + " ᴄʀᴇᴀᴛɪɴɢ ʏᴏᴜʀ ᴘᴀʏᴍᴇɴᴛ ᴏʀᴅᴇʀ...\n" + tgE("5449913031578379785", "🛡️") + " ᴘʟᴇᴀꜱᴇ ᴡᴀɪᴛ ᴀ ꜰᴇᴡ ꜱᴇᴄᴏɴᴅꜱ</blockquote>";

// UPI order for a product: QR for the FULL price, user sends screenshot/UTR, admin approves, key is delivered automatically
function upiOrder(p, pl, i, j, price) {
  var upi = CFG("upi_id", ""), pn = CFG("upi_name", CFG("store_name", "Store"));
  if (!upi) { fail("⚠️ Payments are not set up yet. Please contact support."); return; }
  var mid = null, empty = JSON.stringify({ inline_keyboard: [] });
  if (isCb() && !(request.message.photo)) {
    mid = request.message.message_id;
    try { Api.editMessageText({ chat_id: CID, message_id: mid, text: GEN_TEXT, parse_mode: "HTML", reply_markup: empty }); } catch (e) {}
  }
  ack();
  var uri = "upi://pay?pa=" + upi + "&pn=" + encodeURIComponent(pn) + "&am=" + price + "&cu=INR&tn=" + encodeURIComponent("Order " + UID);
  var qr = "https://api.qrserver.com/v1/create-qr-code/?size=500x500&data=" + encodeURIComponent(uri);
  setState({ t: "buy_proof", i: i, j: j, amount: price, pname: p.name, plabel: pl.label });
  User.setProperty("cp", "", "string");
  var cap = tgE(ICON_BAG, "💰") + " <b>PAY " + rs(price) + " — UPI PAY</b>\n" + RULE + "\n" +
    "<b>PRODUCT</b> | " + esc(p.name) + "\n<b>PLAN</b> | " + esc(pl.label) + "\n" +
    "<b>AMOUNT</b> | " + rs(price) + "\n<b>UPI ID</b> | <code>" + esc(upi) + "</code>\n" + RULE + "\n" +
    "1️⃣ <i>Scan the QR or pay to the UPI ID.</i>\n" +
    "2️⃣ <i>After paying, send the</i> <b>PAYMENT SCREENSHOT</b> <i>(or UTR number) here.</i>\n" +
    "3️⃣ <i>Key is delivered right after admin verifies.</i>";
  Api.sendPhoto({ chat_id: CID, photo: qr, parse_mode: "HTML", caption: cap,
    reply_markup: JSON.stringify({ inline_keyboard: [[B("Cancel", "/prod " + i, "danger", ICON_BACK)]] }) });
  if (mid) { try { Api.deleteMessage({ chat_id: CID, message_id: mid }); } catch (e) {} }
}

// ---------- maintenance / stock-out helpers ----------
// ---------- Reseller API helpers ----------
var RS_DEFAULT = "https://galumodz.shop/api/reseller_v1.php";
function rsUrl() { return CFG("rs_url", RS_DEFAULT); }
function rsOn() { return !!CFG("rs_key", ""); }
// ADAPT ONLY THIS FUNCTION if your TeleBotHost build sends HTTP.post bodies differently.
// The Reseller API expects a normal form POST (api_key, action, product_id, duration, quantity).
function rsPost(fields, okCmd, errCmd) {
  var parts = [];
  for (var fk in fields) if (fields[fk] !== "" && fields[fk] !== null && typeof fields[fk] !== "undefined") parts.push(encodeURIComponent(fk) + "=" + encodeURIComponent(String(fields[fk])));
  HTTP.post({ url: rsUrl(), headers: { "Content-Type": "application/x-www-form-urlencoded", "X-API-Key": CFG("rs_key", "") }, body: parts.join("&"), success: okCmd, error: errCmd });
}
function planOut(pl) { if (!pl || pl.out) return true; if ((pl.keys || []).length) return false; return !(pl.pid && rsOn()); }
function prodAvail(p) { if (!p || p.maint || !p.plans) return false; for (var q = 0; q < p.plans.length; q++) if (!planOut(p.plans[q])) return true; return false; }

// ---------- Proofs channel (purchase feedback post) ----------
// Posts "User Buy Feedback" to the admin-set proof channel. Returns "" on success, else the error text.
function proofSend(name, uid, pname, plabel, key) {
  try {
    var ch = String(CFG("proof_chat", "")).trim();
    if (!ch) return "Proof channel is not set.";
    var pbu = String(CFG("proof_bot", "Galu_Modz_Shop_Bot")).replace(/^https?:\/\/t\.me\//i, "").replace(/^@/, "").trim();
    var pid0 = String(uid), pmid = pid0.length > 6 ? pid0.slice(0, 3) + "***" + pid0.slice(-3) : pid0.slice(0, 1) + "***";
    var pk = String(key || "").split("\n")[0], pmk = "Key:********" + pk.slice(-3);
    var ptm = new Date(Date.now() + 19800000).toISOString().slice(0, 19).replace("T", " ");
    var ptext = "┌ 🔔 <b>User Buy Feedback</b>\n│\n" +
      "├ 👤 <b>Name:</b> " + esc(name || "User") + "\n" +
      "├ 🆔 <b>User ID:</b> " + pmid + "\n" +
      "├ ⚙️ <b>Action:</b> Purchased: " + esc(pname) + " (" + esc(plabel) + ")\n" +
      "├ 🔑 <b>Key Delivered:</b> " + esc(pmk) + "\n" +
      "└ 📅 <b>Time:</b> " + ptm;
    var po = { chat_id: ch, text: ptext, parse_mode: "HTML", disable_web_page_preview: true };
    if (pbu) po.reply_markup = JSON.stringify({ inline_keyboard: [[{ text: "Start Bot & Buy Now", url: "https://t.me/" + pbu, style: "success" }]] });
    var pr = Api.sendMessage(po);
    if (pr && pr.ok === false) { var pw = String(pr.description || pr.error || "send failed"); Bot.setProperty("proof_last_error", pw, "string"); return pw; }
    Bot.setProperty("proof_last_error", "", "string");
    return "";
  } catch (e) { Bot.setProperty("proof_last_error", String(e.message), "string"); return String(e.message); }
}

try {
  var u = ensureUser(); clearState();
  var a = String(params || "").trim().split(/\s+/);
  var i = parseInt(a[0], 10), j = parseInt(a[1], 10), viaUpiBtn = (a[2] === "upi");
  var ps = products();
  var p = ps[i], pl = p && p.plans[j];
  if (!pl) { fail("❌ Plan not found!"); return; }
  if (p.maint) { fail("🛠 This product is under maintenance. Please check back later."); return; }
  if (planOut(pl)) { fail("🚫 Stock Out! This plan is not available right now."); return; }
  var price = calcPrice(planBase(pl, u), u);

  // wallet low -> send user to Add Balance (gateway QR only, no UPI QR)
  if (viaUpiBtn || num(u.bal, 0) < price) {
    show("💰 <b>Wallet balance low.</b>\n\nAdd <b>" + rs(Math.max(0, price - num(u.bal, 0))) + "</b> to your wallet, then buy this plan.",
      [[B("Add Balance", "/addfund", "success", ICON_BAG)], [B("Back", "/prod " + i, "danger", ICON_BACK)]]);
    return;
  }

  // no manual key left -> auto key from the Reseller API (plan has a PID)
  if (!pl.keys || !pl.keys.length) {
    var pp = User.getProperty("rs_pend");
    if (pp && typeof pp === "object" && Date.now() - num(pp.t, 0) < 90000) { fail("⏳ Your previous order is still processing. Please wait a moment."); return; }
    u.bal = r2(u.bal - price); saveUser(u);
    User.setProperty("cp", "", "string");
    User.setProperty("rs_pend", { i: i, j: j, price: price, pname: p.name, plabel: pl.label, pid: String(pl.pid), mid: isCb() ? request.message.message_id : null, t: Date.now() }, "json");
    show("⏳ <b>Processing your order...</b>\n\nPlease wait a few seconds, your key is being generated.", []);
    try {
      rsPost({ api_key: CFG("rs_key", ""), action: "buy", product_id: pl.pid, duration: pl.apidur || "", quantity: 1 }, "/rsbuy ok", "/rsbuy err");
    } catch (e) {
      u = loadUser(UID); u.bal = r2(u.bal + price); saveUser(u);
      User.setProperty("rs_pend", "", "string");
      Bot.setProperty("rs_last_error", "send: " + String(e.message), "string");
      show("❌ <b>Order failed.</b>\n\nYour balance was not charged. Please try again later.", [[B("Back", "/prod " + i, "danger", ICON_BACK)]]);
    }
    return;
  }

  var key = pl.keys.shift();
  saveProducts(ps);
  User.setProperty("cp", "", "string");

  u.bal = r2(u.bal - price);
  u.spent = r2(u.spent + price);
  u.order_count = (u.order_count || 0) + 1;
  u.orders.push({ t: Date.now(), p: p.name, l: pl.label, price: price, key: key });
  if (u.orders.length > 100) u.orders = u.orders.slice(-100);

  // referral bonus: paid once, on the referred user's first purchase
  if (u.ref_by && !u.ref_paid) {
    var ref = loadUser(u.ref_by);
    if (ref) {
      var bonus = num(CFG("ref_bonus", 2), 2);
      ref.bal = r2(num(ref.bal, 0) + bonus); ref.refs = (ref.refs || 0) + 1; ref.ref_earn = r2(num(ref.ref_earn, 0) + bonus);
      saveUser(ref);
      if (bonus > 0) sendTo(ref.id, "🎉 <b>Referral reward!</b>\nYour friend made their first purchase.\n💰 You earned <b>" + money(bonus) + "</b>");
    }
    u.ref_paid = true;
  }
  saveUser(u);
  inc("st_orders", 1); inc("st_revenue", price);

  sendTo(OWNER, "🛒 <b>New Order</b>\n👤 " + esc(u.name) + " (<code>" + u.id + "</code>)\n📦 " + esc(p.name) + " — " + esc(pl.label) + "\n💵 " + money(price) + "\n📊 Left in plan: " + pl.keys.length);

  var pUpd = linkOf(p.upd_link || CFG("update_link", ""));
  var updBtn = pUpd ? Ub("Update Channel", pUpd, "success", "4947513368182260483") : B("Update Channel", "/update", "success", "4947513368182260483");
  // Copy Key: Telegram copies the key text straight to the clipboard on tap
  var copyBtn = String(key).length <= 256
    ? { text: "Copy Key", copy_text: { text: String(key) }, style: "success" }
    : B("Copy Key", "/hist orders", "success");
  var pItem = p.icon ? tgE(String(p.icon), "📦") : "📦";
  var okText = tgE("5390846416530716134", "✅") + " <b>Purchase Successful!</b>\n\n" +
    pItem + " " + esc(p.name) + " — " + esc(pl.label) + "\n" +
    tgE("5255981634527704754", "💵") + " Paid: <b>" + money(price) + "</b>\n\n" +
    tgE("5422779872038626214", "🔑") + " <b>Your Key:</b>\n<code>" + esc(key) + "</code>\n\n" +
    tgE("5233326571099534068", "🌑") + " Balance left: <b>" + money(u.bal) + "</b>\n" +
    "<i>Saved in My Profile → Orders anytime.</i>";
  var fullRows = [
    [copyBtn],
    [updBtn],
    [B("Buy More", "/buy", "danger", "6093562529978522804"), B("Menu", "/back", "primary", "5240177683886784793")]
  ];
  var plainRows = (pUpd ? [[Ub("Update Channel", pUpd, "success")]] : []).concat([
    [B("Buy More", "/buy", "danger"), B("Menu", "/back", "primary")]
  ]);
  try { show(okText, fullRows); }
  catch (e2) {
    // a button the client/API refused: still deliver the key with plain buttons
    try { show(okText, plainRows); } catch (e3) { sendTo(CID, okText, plainRows); }
  }
  proofSend(u.name, u.id, p.name, pl.label, key);
} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}
