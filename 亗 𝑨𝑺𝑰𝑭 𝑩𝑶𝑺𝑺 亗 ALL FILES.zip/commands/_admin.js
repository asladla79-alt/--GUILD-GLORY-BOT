/**#command
name: /admin
answer:
keyboard:
parse_mode: markdown
aliases:
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// ================= SHARED HELPERS (auto-included in every command) =================
function CFG(k, d) { var v = Bot.getProperty(k); return (v === null || typeof v === "undefined" || v === "") ? d : v; }
function num(v, d) { var n = Number(v); return isFinite(n) ? n : d; }
function r2(n) { return Math.round(num(n, 0) * 100) / 100; }
function esc(s) { return String(s === null || typeof s === "undefined" ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
function money(n) { return "₹" + r2(n).toFixed(2); }
function fmtDate(t) { if (!t) return "-"; return new Date(Number(t) + 19800000).toISOString().slice(0, 16).replace("T", " "); }

var OWNER = String(CFG("owner_id", "2049656553"));
var UID = String(user.telegramid);
var CID = chat.chatid;
var IS_NEW = false;

function isAdmin(id) { id = String(typeof id === "undefined" ? UID : id); return id === OWNER || !!Bot.getProperty("co_admin_" + id); }
function displayName() { var n = String((user.first_name || "") + " " + (user.last_name || "")).trim(); return n || user.username || "User"; }

// ---------- users ----------
function newUser(id) {
  return { id: String(id), name: displayName(), username: user.username || "", joined: Date.now(), bal: 0, spent: 0,
    order_count: 0, orders: [], topups: [], ref_by: null, ref_paid: false, refs: 0, ref_earn: 0, last_daily: 0, daily_total: 0 };
}
function loadUser(id) { var u = Bot.getProperty("u_" + id); return (u && typeof u === "object") ? u : null; }
function saveUser(u) { Bot.setProperty("u_" + u.id, u, "json"); }
function ensureUser() {
  var u = loadUser(UID);
  if (!u) {
    u = newUser(UID); IS_NEW = true;
    var list = Bot.getProperty("users");
    if (!Array.isArray(list)) list = [];
    list.push(UID);
    Bot.setProperty("users", list, "json");
  } else {
    u.name = displayName(); u.username = user.username || "";
  }
  saveUser(u);
  return u;
}

// ---------- conversation state ----------
function getState() { var s = User.getProperty("st"); return (s && typeof s === "object") ? s : null; }
function setState(o) { User.setProperty("st", o, "json"); }
function clearState() { User.setProperty("st", "", "string"); }

// ---------- products ----------
function products() { var p = Bot.getProperty("products"); return Array.isArray(p) ? p : []; }
function saveProducts(p) { Bot.setProperty("products", p, "json"); }
function stockOf(prod) { var n = 0; if (prod && prod.plans) for (var i = 0; i < prod.plans.length; i++) n += (prod.plans[i].keys || []).length; return n; }
function discPct() { return 0; }
function finalPrice(price, u) { return r2(num(price, 0)); }
function inc(k, by) { Bot.setProperty(k, String(r2(num(Bot.getProperty(k), 0) + by)), "string"); }

function linkOf(v) {
  v = String(v || "").trim(); if (!v) return "";
  if (/^https?:\/\//i.test(v)) return v;
  if (/^t\.me\//i.test(v)) return "https://" + v;
  return "https://t.me/" + v.replace(/^@/, "");
}

// ---------- telegram helpers ----------
function B(text, data, style, icon) { var b = { text: text, callback_data: data }; if (style) b.style = style; if (icon) b.icon_custom_emoji_id = String(icon); return b; }
function Ub(text, url, style) { var b = { text: text, url: url }; if (style) b.style = style; return b; }
function qid() { if (!request) return null; return request.id || (request.callback_query && request.callback_query.id) || null; }
function isCb() { return !!(request && request.message && request.message.message_id && qid()); }
function ack(text, alert) {
  var q = qid(); if (!q) return;
  try { var o = { callback_query_id: String(q) }; if (text) { o.text = text; o.show_alert = !!alert; } Api.answerCallbackQuery(o); } catch (e) {}
}
function fail(text) { if (qid()) ack(text, true); else Api.sendMessage({ chat_id: CID, text: text }); }
function sendTo(id, text, rows) {
  var o = { chat_id: id, text: text, parse_mode: "HTML", disable_web_page_preview: true };
  if (rows) o.reply_markup = JSON.stringify({ inline_keyboard: rows });
  try { Api.sendMessage(o); } catch (e) {}
}
// Edit the tapped message (or send a new one when called from plain text / a photo message)
function show(text, rows) {
  var markup = JSON.stringify({ inline_keyboard: rows || [] });
  ack();
  if (isCb()) {
    var m = request.message;
    if (m.photo || m.video || m.document) {
      try { Api.deleteMessage({ chat_id: CID, message_id: m.message_id }); } catch (e) {}
      Api.sendMessage({ chat_id: CID, text: text, parse_mode: "HTML", disable_web_page_preview: true, reply_markup: markup });
    } else {
      Api.editMessageText({ chat_id: CID, message_id: m.message_id, text: text, parse_mode: "HTML", disable_web_page_preview: true, reply_markup: markup });
    }
  } else {
    Api.sendMessage({ chat_id: CID, text: text, parse_mode: "HTML", disable_web_page_preview: true, reply_markup: markup });
  }
}
var BACK = [B("Back", "/back", "primary", "5240177683886784793")];
// ---------- global Maintenance Mode (bot off for all users; admins bypass) ----------
if (CFG("maint_mode", "") === "1" && !isAdmin()) {
  try {
    var mmLink = linkOf(CFG("update_link", ""));
    show("🛠 <b>Bot Under Maintenance</b>\n\nThe bot is currently under maintenance. Please check back later — sorry for the inconvenience!",
      mmLink ? [[{ text: "Check Update", url: mmLink, style: "primary" }]] : []);
  } catch (e) {}
  return;
}

// ---------- device types (premium icon ids: put the custom emoji id in "icon", else the plain emoji in "fb" is used) ----------
var DEVICES = loadDevices();
function loadDevices() {
  var d = Bot.getProperty("devices");
  if (Array.isArray(d)) return d;
  return [
  { k: "anr", label: "ANDROID NONROOT", icon: "5929253286145166951", fb: "🤖" },
  { k: "ar",  label: "ANDROID ROOT",    icon: "5929253286145166951", fb: "🤖" },
  { k: "pc",  label: "PC / COMPUTER",   icon: "5440784572511972384", fb: "💻" },
  { k: "ios", label: "IOS / IPHONE",    icon: "5262960432397689651", fb: "🍎" }
];
}
function saveDevices(arr) { Bot.setProperty("devices", arr, "json"); DEVICES = arr; }
function devOf(k) { for (var d = 0; d < DEVICES.length; d++) if (DEVICES[d].k === k) return DEVICES[d]; return null; }
function devBtn(d, data) { return B(d.icon ? d.label : d.fb + " " + d.label, data, "primary", d.icon); }

// ---------- Reseller API helpers ----------
var RS_DEFAULT = "https://galumodz.shop/api/reseller_v1.php";
function rsUrl() { return CFG("rs_url", RS_DEFAULT); }
function rsOn() { return !!CFG("rs_key", ""); }
// ADAPT ONLY THIS FUNCTION if your TeleBotHost build sends HTTP.post bodies differently.
// The Reseller API expects a normal form POST (api_key, action, product_id, duration, quantity).
function rsPost(fields, okCmd, errCmd) {
  var parts = [];
  for (var fk in fields) if (fields[fk] !== "" && fields[fk] !== null && typeof fields[fk] !== "undefined") parts.push(encodeURIComponent(fk) + "=" + encodeURIComponent(String(fields[fk])));
  HTTP.post({ url: rsUrl(), headers: { "Content-Type": "application/x-www-form-urlencoded", "X-API-Key": CFG("rs_key", "") }, body: parts.join("&"), success: okCmd, error: errCmd });
}

// ---------- Proofs channel (purchase feedback post) ----------
// Posts "User Buy Feedback" to the admin-set proof channel. Returns "" on success, else the error text.
function proofSend(name, uid, pname, plabel, key) {
  try {
    var ch = String(CFG("proof_chat", "")).trim();
    if (!ch) return "Proof channel is not set.";
    var pbu = String(CFG("proof_bot", "Galu_Modz_Shop_Bot")).replace(/^https?:\/\/t\.me\//i, "").replace(/^@/, "").trim();
    var pid0 = String(uid), pmid = pid0.length > 6 ? pid0.slice(0, 3) + "***" + pid0.slice(-3) : pid0.slice(0, 1) + "***";
    var pk = String(key || "").split("\n")[0], pmk = "Key:********" + pk.slice(-3);
    var ptm = new Date(Date.now() + 19800000).toISOString().slice(0, 19).replace("T", " ");
    var ptext = "┌ 🔔 <b>User Buy Feedback</b>\n│\n" +
      "├ 👤 <b>Name:</b> " + esc(name || "User") + "\n" +
      "├ 🆔 <b>User ID:</b> " + pmid + "\n" +
      "├ ⚙️ <b>Action:</b> Purchased: " + esc(pname) + " (" + esc(plabel) + ")\n" +
      "├ 🔑 <b>Key Delivered:</b> " + esc(pmk) + "\n" +
      "└ 📅 <b>Time:</b> " + ptm;
    var po = { chat_id: ch, text: ptext, parse_mode: "HTML", disable_web_page_preview: true };
    if (pbu) po.reply_markup = JSON.stringify({ inline_keyboard: [[{ text: "Start Bot & Buy Now", url: "https://t.me/" + pbu, style: "success" }]] });
    var pr = Api.sendMessage(po);
    if (pr && pr.ok === false) { var pw = String(pr.description || pr.error || "send failed"); Bot.setProperty("proof_last_error", pw, "string"); return pw; }
    Bot.setProperty("proof_last_error", "", "string");
    return "";
  } catch (e) { Bot.setProperty("proof_last_error", String(e.message), "string"); return String(e.message); }
}

// Admin panel. One command, many screens:  /admin [action] [args...]
try {
  if (!isAdmin()) { fail("❌ Restricted! Admin only."); return; }
  clearState();
  var a = String(params || "").trim().split(/\s+/).filter(function (x) { return x; });
  var act = a[0] || "home";
  var AB = [B("Admin Panel", "/admin", "primary", "5240177683886784793")];
  var ps, i, j, p, rows, text;

  // global Maintenance Mode toggle, then back to the admin home
  if (act === "mmode") {
    Bot.setProperty("maint_mode", CFG("maint_mode", "") === "1" ? "" : "1", "string");
    act = "home";
  }


  // ---- Proofs Send Set ----
  if (act === "proofs") {
    var pchv = CFG("proof_chat", ""), pbv = String(CFG("proof_bot", "Galu_Modz_Shop_Bot")), perr = CFG("proof_last_error", "");
    show("🧾 <b>Proofs Send Set</b>\n\n" +
      (pchv ? "✅ " : "❌ ") + "<b>Proof Channel</b>\n<code>" + esc(pchv || "not set") + "</code>\n\n" +
      "✅ <b>Bot Username</b> (Start Bot &amp; Buy Now button)\n<code>@" + esc(pbv) + "</code>\n\n" +
      (pchv ? "<i>Every key purchase is posted to the channel automatically. Add this bot as an admin of the channel.</i>" : "<i>Set the proof channel to turn proof posts on.</i>") +
      (perr ? "\n\n⚠️ <b>Last error:</b> <code>" + esc(perr) + "</code>" : ""),
      [
        [B("📣 Set Proof Channel", "/admin set proof_chat", "success"), B("🤖 Set Bot Username", "/admin set proof_bot", "primary")],
        [B("📤 Send Test Proof", "/admin proofsend", "success")],
        AB
      ]);
    return;
  }
  if (act === "proofsend") {
    var pser = proofSend(displayName(), UID, "TEST PRODUCT", "1 Day", "TEST-KEY-000");
    show(pser ? "❌ <b>Test proof failed</b>\n\n<code>" + esc(pser) + "</code>\n\nMake sure the channel is set and this bot is an <b>admin</b> of that channel." : "✅ <b>Test proof sent</b> to your proof channel.",
      [[B("Back", "/admin proofs", "danger", "5240177683886784793")]]);
    return;
  }

  // ---- Reseller API Set ----
  if (act === "rsapi") {
    var rkv = CFG("rs_key", "");
    show("<tg-emoji emoji-id=\"6327860610952340543\">🔌</tg-emoji> <b>Reseller API Set</b>\n\n" +
      (rkv ? "✅ " : "❌ ") + "<b>API Key</b>\n<code>" + esc(rkv ? "••••" + String(rkv).slice(-4) : "not set") + "</code>\n\n" +
      "✅ <b>API URL</b>\n<code>" + esc(rsUrl()) + "</code>\n\n" +
      (rkv ? "<i>Auto keys are ON. A plan with a PID gets its key from the API when it has no manual keys left.</i>" : "<i>Set the API Key to turn on auto keys.</i>"),
      [
        [B("🔑 Set API Key", "/admin set rs_key", "success"), B("🔗 Set API URL", "/admin set rs_url", "primary")],
        [B("💰 Check API Balance", "/admin rsbal", "success")],
        AB
      ]);
    return;
  }
  if (act === "rsbal") {
    if (!rsOn()) { fail("❌ Set the API Key first."); return; }
    show("⏳ <b>Checking Reseller API balance...</b>", [[B("Back", "/admin rsapi", "danger", "5240177683886784793")]]);
    try { rsPost({ api_key: CFG("rs_key", ""), action: "balance" }, "/rsbuy bal", "/rsbuy berr"); }
    catch (e) { sendTo(CID, "❌ Could not call the API: <code>" + esc(e.message) + "</code>", [[B("Back", "/admin rsapi", "danger", "5240177683886784793")]]); }
    return;
  }
  if (act === "setpid" || act === "setadur") {
    i = parseInt(a[1], 10); j = parseInt(a[2], 10); p = products()[i];
    if (!p || !p.plans[j]) { fail("❌ Plan not found"); return; }
    var isPid = act === "setpid";
    ask({ t: act, i: i, j: j },
      (isPid ? "🆔 <b>PID (Reseller API CODE)</b>" : "⏱ <b>API Duration</b>") + " — " + esc(p.name) + " / " + esc(p.plans[j].label) +
      "\n\nCurrent: <code>" + esc((isPid ? p.plans[j].pid : p.plans[j].apidur) || "— (not set)") + "</code>\n\n" +
      (isPid ? "Send the <b>PID</b> from your Reseller API product table (e.g. <code>32</code>).\nThis plan will then deliver keys automatically." : "Send the duration text exactly as the API expects (e.g. <code>1 HOURS</code>).\nNeeded only when the PID is shared by many durations.") +
      "\nSend <code>-</code> to clear it.", "/admin prod " + i);
    return;
  }

  // ---- Keys In Stock manager ----
  var KI = "6005570495603282482";
  var keTe = function (id, fb) { return "<tg-emoji emoji-id=\"" + id + "\">" + fb + "</tg-emoji>"; };
  if (act === "kdel") {
    i = parseInt(a[1], 10); j = parseInt(a[2], 10); ps = products();
    if (!ps[i] || !ps[i].plans[j]) { fail("❌ Plan not found"); return; }
    var kdl = ps[i].plans[j].keys || [], kdi = parseInt(a[3], 10);
    if (kdi >= 0 && kdi < kdl.length) { kdl.splice(kdi, 1); ps[i].plans[j].keys = kdl; saveProducts(ps); }
    a[3] = a[4] || "0"; act = "keysl";
  }
  if (act === "kdelallok") {
    i = parseInt(a[1], 10); j = parseInt(a[2], 10); ps = products();
    if (!ps[i] || !ps[i].plans[j]) { fail("❌ Plan not found"); return; }
    ps[i].plans[j].keys = []; saveProducts(ps);
    a[3] = "0"; act = "keysl";
  }
  if (act === "kdelall") {
    i = parseInt(a[1], 10); j = parseInt(a[2], 10); p = products()[i];
    if (!p || !p.plans[j]) { fail("❌ Plan not found"); return; }
    show("🗑 Delete <b>ALL " + (p.plans[j].keys || []).length + " keys</b> of <b>" + esc(p.name) + " — " + esc(p.plans[j].label) + "</b>?\n\n<b>This cannot be undone.</b>",
      [[B("✅ Yes, delete all", "/admin kdelallok " + i + " " + j, "danger"), B("❌ No", "/admin keysl " + i + " " + j + " 0", "primary")]]);
    return;
  }
  if (act === "keysl") {
    i = parseInt(a[1], 10); j = parseInt(a[2], 10); p = products()[i];
    if (!p || !p.plans[j]) { fail("❌ Plan not found"); return; }
    var kl = p.plans[j].keys || [], KPER = 10;
    var kpages = Math.max(1, Math.ceil(kl.length / KPER));
    var kpg = Math.max(0, parseInt(a[3], 10) || 0); if (kpg >= kpages) kpg = kpages - 1;
    text = keTe(KI, "🔑") + " <b>Keys In Stock</b>\n📦 " + esc(p.name) + " — " + esc(p.plans[j].label) + "\n🔑 Total: <b>" + kl.length + "</b>  |  📄 Page " + (kpg + 1) + "/" + kpages + "\n\n";
    rows = []; var drow = [];
    if (!kl.length) text += "No keys in stock.\n";
    for (var ki = kpg * KPER; ki < Math.min(kl.length, (kpg + 1) * KPER); ki++) {
      text += (ki + 1) + ". <code>" + esc(String(kl[ki]).slice(0, 60)) + "</code>\n";
      drow.push(B("🗑 " + (ki + 1), "/admin kdel " + i + " " + j + " " + ki + " " + kpg, "danger"));
      if (drow.length === 5) { rows.push(drow); drow = []; }
    }
    if (drow.length) rows.push(drow);
    var knav = [];
    if (kpg > 0) knav.push(B("⬅️ Prev", "/admin keysl " + i + " " + j + " " + (kpg - 1), "primary"));
    if (kpg < kpages - 1) knav.push(B("Next ➡️", "/admin keysl " + i + " " + j + " " + (kpg + 1), "primary"));
    if (knav.length) rows.push(knav);
    if (kl.length) rows.push([B("🗑 Delete All Keys", "/admin kdelall " + i + " " + j, "danger")]);
    rows.push([B("➕ Add Keys", "/admin addkeys " + i + " " + j, "success")]);
    rows.push([B("Back", "/admin keysp " + i, "danger", "5240177683886784793")]);
    show(text, rows);
    return;
  }
  if (act === "keysp") {
    i = parseInt(a[1], 10); p = products()[i];
    if (!p) { fail("❌ Product not found"); return; }
    rows = [];
    for (j = 0; j < p.plans.length; j++) rows.push([B(p.plans[j].label + " — " + (p.plans[j].keys || []).length + " keys", "/admin keysl " + i + " " + j + " 0", (p.plans[j].keys || []).length ? "success" : "danger", KI)]);
    rows.push([B("Back", "/admin keys", "danger", "5240177683886784793")]);
    show(keTe(KI, "🔑") + " <b>Keys In Stock</b> — " + esc(p.name) + "\n\nSelect a plan to see its keys." + (p.plans.length ? "" : "\n\nNo plans yet."), rows);
    return;
  }
  if (act === "keys") {
    ps = products(); rows = [];
    for (i = 0; i < ps.length; i++) rows.push([B(ps[i].name + " (" + stockOf(ps[i]) + ")", "/admin keysp " + i, stockOf(ps[i]) ? "success" : "danger", ps[i].icon ? String(ps[i].icon) : "")]);
    rows.push(AB);
    show(keTe(KI, "🔑") + " <b>Keys In Stock</b>\n\nSelect a product to see the keys added in each plan. You can delete keys there." + (ps.length ? "" : "\n\nNo products yet."), rows);
    return;
  }

  // ---- Maintenance manager (admin home) ----
  if (act === "mt") {
    i = parseInt(a[1], 10); ps = products();
    if (!ps[i]) { fail("❌ Product not found"); return; }
    if (ps[i].maint) delete ps[i].maint; else ps[i].maint = true;
    saveProducts(ps);
    act = "maints";
  }
  if (act === "maints") {
    ps = products(); rows = [];
    for (i = 0; i < ps.length; i++) rows.push([B((ps[i].maint ? "🔴 ON  — " : "🟢 OFF — ") + ps[i].name, "/admin mt " + i, ps[i].maint ? "danger" : "success", ps[i].icon ? String(ps[i].icon) : "")]);
    rows.push(AB);
    show("🛠 <b>Maintenance</b>\n\nTap a product to turn Maintenance ON/OFF.\n🔴 ON = users see the maintenance screen (red button)\n🟢 OFF = normal" + (ps.length ? "" : "\n\nNo products yet."), rows);
    return;
  }

  // ---- Stock Out manager (admin home) ----
  if (act === "ot") {
    i = parseInt(a[1], 10); j = parseInt(a[2], 10); ps = products();
    if (!ps[i] || !ps[i].plans[j]) { fail("❌ Plan not found"); return; }
    if (ps[i].plans[j].out) delete ps[i].plans[j].out; else ps[i].plans[j].out = true;
    saveProducts(ps);
    act = "outp"; a[1] = String(i);
  }
  if (act === "outp") {
    i = parseInt(a[1], 10); p = products()[i];
    if (!p) { fail("❌ Product not found"); return; }
    rows = [];
    for (j = 0; j < p.plans.length; j++) rows.push([B((p.plans[j].out ? "🔴 STOCK OUT — " : "🟢 In stock — ") + p.plans[j].label + " (🔑 " + (p.plans[j].keys || []).length + ")", "/admin ot " + i + " " + j, p.plans[j].out ? "danger" : "success")]);
    rows.push([B("Back", "/admin outs", "danger", "5240177683886784793")]);
    show("🚫 <b>Stock Out</b> — " + esc(p.name) + "\n\nTap a plan to turn Stock Out ON/OFF.\n🔴 STOCK OUT = red button, user cannot buy" + (p.plans.length ? "" : "\n\nNo plans yet."), rows);
    return;
  }
  if (act === "outs") {
    ps = products(); rows = [];
    for (i = 0; i < ps.length; i++) rows.push([B("📦 " + ps[i].name, "/admin outp " + i, "primary", ps[i].icon ? String(ps[i].icon) : "")]);
    rows.push(AB);
    show("🚫 <b>Stock Out</b>\n\nSelect a product, then choose the plan (1 Day / 3 Days / 7 Days...) to set Stock Out." + (ps.length ? "" : "\n\nNo products yet."), rows);
    return;
  }

  // toggle product Maintenance, then fall through to the product screen
  if (act === "maint") {
    i = parseInt(a[1], 10); ps = products();
    if (!ps[i]) { fail("❌ Product not found"); return; }
    if (ps[i].maint) delete ps[i].maint; else ps[i].maint = true;
    saveProducts(ps);
    act = "prod"; a[1] = String(i);
  }
  // toggle plan Stock Out, then fall through to the product screen
  if (act === "plout") {
    i = parseInt(a[1], 10); j = parseInt(a[2], 10); ps = products();
    if (!ps[i] || !ps[i].plans[j]) { fail("❌ Plan not found"); return; }
    if (ps[i].plans[j].out) delete ps[i].plans[j].out; else ps[i].plans[j].out = true;
    saveProducts(ps);
    act = "prod"; a[1] = String(i);
  }

  // delete a plan, then fall through to the product screen
  if (act === "delplan") {
    i = parseInt(a[1], 10); j = parseInt(a[2], 10); ps = products();
    if (!ps[i] || !ps[i].plans[j]) { fail("❌ Plan not found"); return; }
    ps[i].plans.splice(j, 1); saveProducts(ps);
    act = "prod"; a[1] = String(i);
  }

  // set product device, then fall through to the product screen
  if (act === "setdev") {
    i = parseInt(a[1], 10); ps = products();
    if (!ps[i]) { fail("❌ Product not found"); return; }
    if (devOf(a[2])) ps[i].dev = a[2]; else delete ps[i].dev;
    saveProducts(ps);
    var dsel = devOf(a[2]);
    show("✅ <b>" + esc(ps[i].name) + "</b> saved for: <b>" + (dsel ? esc(dsel.label) : "🌐 ALL DEVICES") + "</b>\n\nNow add plans & keys 👇",
      [[B("➕ Add Plan", "/admin addplan " + i, "success")],
       [B("📦 Open Product", "/admin prod " + i, "primary")],
       [B("📱 Change Device", "/admin dev " + i, "primary")],
       AB]);
    return;
  }
  if (act === "dev") {
    i = parseInt(a[1], 10); p = products()[i];
    if (!p) { fail("❌ Product not found"); return; }
    rows = [];
    for (j = 0; j < DEVICES.length; j++) rows.push([devBtn(DEVICES[j], "/admin setdev " + i + " " + DEVICES[j].k)]);
    rows.push([B("🌐 All Devices", "/admin setdev " + i + " all", "success")]);
    rows.push([B("➕ Add New Device", "/admin adddev", "success"), B("📱 Manage Devices", "/admin devices", "primary")]);
    rows.push([B("Back", "/admin prod " + i, "danger", "5240177683886784793")]);
    show("📱 <b>" + esc(p.name) + "</b>\n\nWhich device is this product for?", rows);
    return;
  }

  function ask(st, prompt, backCmd) {
    setState(st);
    show(prompt + "\n\n<i>Send /cancel to abort.</i>", [[B("Cancel", backCmd || "/admin", "danger", "5240177683886784793")]]);
  }

  if (act === "home") {
    var users = Bot.getProperty("users"); users = Array.isArray(users) ? users.length : 0;
    ps = products(); var stock = 0;
    for (i = 0; i < ps.length; i++) stock += stockOf(ps[i]);
    var te = function (id, fb) { return "<tg-emoji emoji-id=\"" + id + "\">" + fb + "</tg-emoji>"; };
    show(te("5433758796289685818", "👑") + " <b>Admin Panel</b>\n\n" +
      te("5985378660343877179", "👥") + " Users: <b>" + users + "</b>\n" +
      "📦 Products: <b>" + ps.length + "</b>  |  " + te("6005570495603282482", "🔑") + " Keys in stock: <b>" + stock + "</b>\n" +
      te("6093562529978522804", "🛒") + " Orders: <b>" + num(Bot.getProperty("st_orders"), 0) + "</b>  |  " + te("5224257782013769471", "💵") + " Revenue: <b>" + money(num(Bot.getProperty("st_revenue"), 0)) + "</b>\n" +
      te("5445353829304387411", "💳") + " Top-ups approved: <b>" + money(num(Bot.getProperty("st_topup"), 0)) + "</b>" +
      (CFG("maint_mode", "") === "1" ? "\n\n🔴 <b>BOT MAINTENANCE MODE IS ON</b> — all users are blocked." : ""),
      [
        [B("Add Product", "/admin addprod", "success", "5397916757333654639"), B("Total User", "/admin users", "primary", "5985378660343877179")],
        [B("Add Balance", "/admin bal add", "success", "5224257782013769471"), B("Remove Balance", "/admin bal sub", "danger", "5224257782013769471")],
        [B("Manage Products", "/admin prods", "primary", "5388683870432410767"), B("Coupons", "/admin coupons", "success", "5249061621875100582")],
        [B("Maintenance Mode", "/admin mmode", CFG("maint_mode", "") === "1" ? "danger" : "success", "6289607476140575751"), B("Message All User", "/admin bc", "primary", "5472180551517477902")],
        [B("Maintenance", "/admin maints", "danger", "5264908182886557148"), B("Stock Out", "/admin outs", "danger", "5363855407523589500")],
        [B("All Update Channel", "/admin upd", "primary", "5132275778855109939"), B("How To Use", "/admin howto", "primary", "5458675550841219843")],
        [B("Support Set", "/admin set support_link", "primary", "6010260496811299512"), B("Refer And Price Set", "/admin set ref_bonus", "primary", "5258023599419171861")],
        [B("Keys In Stock", "/admin keys", "primary", "6005570495603282482"), B("Payment Settings", "/admin pay", "success", "5258096772776991776")],
        [B("Reseller Upgrade", "/admin resup", "success", "5463277406435422003"), B("Reseller Remove", "/admin resrem", "danger", "5267123797600783095")],
        [B("Reseller Api Set", "/admin rsapi", "primary", "6327860610952340543"), B("🧾 Proofs Send Set", "/admin proofs", "primary")],
        [B("Back to Menu", "/back", "danger", "5240177683886784793")]
      ]);
    return;
  }

  if (act === "users") {
    var uids = Bot.getProperty("users"); uids = Array.isArray(uids) ? uids : [];
    var PER = 15, pg = Math.max(0, parseInt(a[1], 10) || 0);
    var pages = Math.max(1, Math.ceil(uids.length / PER));
    if (pg >= pages) pg = pages - 1;
    var totalBal = 0;
    for (i = 0; i < uids.length; i++) { var ut = loadUser(uids[i]); if (ut) totalBal += num(ut.bal, 0); }
    text = "👥 <b>Total Users: " + uids.length + "</b>\n" +
      "💰 Total Balance: <b>" + money(totalBal) + "</b>\n" +
      "📄 Page " + (pg + 1) + "/" + pages + "\n\n";
    for (i = pg * PER; i < Math.min(uids.length, (pg + 1) * PER); i++) {
      var ux = loadUser(uids[i]);
      if (!ux) continue;
      text += (i + 1) + ". <b>" + esc(ux.name || "—") + "</b>" +
        (ux.username ? " (@" + esc(ux.username) + ")" : "") + "\n" +
        "   🆔 <code>" + esc(ux.id) + "</code>  |  💰 <b>" + money(ux.bal) + "</b>\n";
    }
    if (!uids.length) text += "No users yet.\n";
    rows = [];
    var nav = [];
    if (pg > 0) nav.push(B("⬅️ Prev", "/admin users " + (pg - 1), "primary"));
    if (pg < pages - 1) nav.push(B("Next ➡️", "/admin users " + (pg + 1), "primary"));
    if (nav.length) rows.push(nav);
    rows.push([B("➕ Add Balance", "/admin bal add", "success"), B("💸 Remove Balance", "/admin bal sub", "danger")]);
    rows.push(AB);
    show(text, rows);
    return;
  }

  if (act === "devicon") {
    var ik = a[1] || "", idv = null, idl = loadDevices();
    for (i = 0; i < idl.length; i++) if (idl[i].k === ik) idv = idl[i];
    if (!idv) { fail("❌ Device not found"); return; }
    ask({ t: "devicon", k: ik }, "🎨 <b>Device emoji</b> — " + esc(idv.label) + "\n\nSend a <b>premium emoji</b> now, or send <code>-</code> to remove it.", "/admin devices");
    return;
  }
  if (act === "deldev") {
    var dk = a[1] || "";
    var dv0 = null, dl0 = loadDevices();
    for (i = 0; i < dl0.length; i++) if (dl0[i].k === dk) dv0 = dl0[i];
    if (!dv0) { fail("❌ Device not found"); return; }
    if (a[2] !== "yes") {
      show("🗑 <b>Delete device " + esc(dv0.label) + "?</b>\n\nProducts set only for this device will show under <b>ALL DEVICES</b> after this.\n\n<b>This cannot be undone.</b>",
        [[B("✅ Yes, delete", "/admin deldev " + dk + " yes", "danger"), B("❌ No", "/admin devices", "primary")]]);
      return;
    }
    saveDevices(dl0.filter(function (x) { return x.k !== dk; }));
    ps = products();
    for (i = 0; i < ps.length; i++) if (ps[i].dev === dk) delete ps[i].dev;
    saveProducts(ps);
    act = "devices";
  }
  if (act === "adddev") {
    var ret = a[1] === "addprod" ? "addprod" : "devices";
    ask({ t: "adddev", ret: ret }, "➕ <b>Add New Device</b>\n\nSend the <b>device name</b> (e.g. <code>ANDROID 14</code>):", ret === "addprod" ? "/admin addprod" : "/admin devices");
    return;
  }
  if (act === "devices") {
    var dl = loadDevices(); text = "📱 <b>Devices</b>\n\nTap 🗑 to delete a device.\n\n"; rows = [];
    if (!dl.length) text += "No devices yet.\n";
    for (j = 0; j < dl.length; j++) {
      text += (j + 1) + ". " + esc(dl[j].label) + (dl[j].icon ? " ✅ emoji set" : "") + "\n";
      rows.push([B("🎨 " + dl[j].label, "/admin devicon " + dl[j].k, "primary", dl[j].icon || ""), B("🗑 Delete", "/admin deldev " + dl[j].k, "danger")]);
    }
    rows.push([B("➕ Add Device", "/admin adddev", "success")]);
    rows.push(a[1] === "addprod" ? [B("➕ Continue Add Product", "/admin addprod", "primary")] : AB);
    show(text, rows);
    return;
  }

  if (act === "editname") {
    i = parseInt(a[1], 10); p = products()[i];
    if (!p) { fail("❌ Product not found"); return; }
    ask({ t: "editname", i: i }, "✏️ <b>Edit Name</b>\n\nCurrent: <b>" + esc(p.name) + "</b>\n\nSend the new product name:", "/admin prod " + i);
    return;
  }
  if (act === "editprice" || act === "editrprice") {
    i = parseInt(a[1], 10); j = parseInt(a[2], 10); p = products()[i];
    if (!p || !p.plans[j]) { fail("❌ Plan not found"); return; }
    var isRP = act === "editrprice";
    var curP = isRP ? (p.plans[j].rprice ? money(p.plans[j].rprice) : "— (not set)") : money(p.plans[j].price);
    ask({ t: isRP ? "editrprice" : "editprice", i: i, j: j },
      (isRP ? "🏷 <b>Reseller Price</b>" : "💰 <b>User Price</b>") + " — " + esc(p.name) + " / " + esc(p.plans[j].label) +
      "\n\nCurrent: <b>" + curP + "</b>\n\nSend the new price in ₹:", "/admin prod " + i);
    return;
  }
  if (act === "resup" || act === "resrem") {
    ask({ t: act, }, act === "resup" ? "⬆️ <b>Reseller Upgrade</b>\n\nSend the user's <b>Telegram ID</b> to make them a Reseller:" : "⬇️ <b>Reseller Remove</b>\n\nSend the user's <b>Telegram ID</b> to remove Reseller access:", "/admin");
    return;
  }
  if (act === "icon") {
    i = parseInt(a[1], 10); p = products()[i];
    if (!p) { fail("❌ Product not found"); return; }
    ask({ t: "prodicon", i: i }, "🎨 <b>Product Icon</b> — " + esc(p.name) + "\n\nSend a <b>premium emoji</b> now (or its numeric emoji ID).\nSend <code>-</code> to remove the icon.", "/admin prod " + i);
    return;
  }

  if (act === "upd" || act === "howto") {
    var isU = act === "upd";
    var setKeys = isU ? ["update_btn", "update_link", "update_text"] : ["howto_btn", "howto_link", "howto_text"];
    var setBtn = isU ? "📢 All Update Channel" : "📘 How To Use";
    var setName = { update_btn: "Button Name", update_link: "Link", update_text: "Text", howto_btn: "Button Name", howto_link: "Video / Link", howto_text: "How-To Text" };
    rows = [];
    for (i = 0; i < setKeys.length; i++) rows.push([B("✏️ " + setName[setKeys[i]], "/admin set " + setKeys[i], "primary")]);
    var curLines = "";
    for (i = 0; i < setKeys.length; i++) {
      var sv = String(CFG(setKeys[i], "—")); if (sv.length > 60) sv = sv.slice(0, 60) + "…";
      curLines += setName[setKeys[i]] + ": <code>" + esc(sv) + "</code>\n";
    }
    text = "<b>" + setBtn + "</b>\n\n" + curLines +
      "\nTap below to change. The menu button and the page use these values.";
    rows.push(AB);
    show(text, rows);
    return;
  }

  if (act === "updlink") {
    i = parseInt(a[1], 10); p = products()[i];
    if (!p) { fail("❌ Product not found"); return; }
    ask({ t: "updlink", i: i }, "📢 <b>Update Channel Link</b> — " + esc(p.name) + "\n\nCurrent: <code>" + esc(p.upd_link || "— (uses All Update Channel link)") + "</code>\n\nSend the channel link for this product (e.g. <code>https://t.me/yourchannel</code>).\nSend <code>-</code> to clear it.", "/admin prod " + i);
    return;
  }

  if (act === "delcoupon") {
    var cpl = Bot.getProperty("coupons"); cpl = Array.isArray(cpl) ? cpl : [];
    var di = parseInt(a[1], 10);
    if (cpl[di]) { cpl.splice(di, 1); Bot.setProperty("coupons", cpl, "json"); }
    act = "coupons";
  }
  if (act === "addcoupon") { ask({ t: "addcoupon", stage: "code" }, "🎟 <b>Add Coupon</b>\n\nSend the <b>coupon code</b> (letters/numbers, e.g. <code>GALU10</code>):", "/admin coupons"); return; }
  if (act === "coupons") {
    var cl = Bot.getProperty("coupons"); cl = Array.isArray(cl) ? cl : [];
    text = "🎟 <b>Coupons</b>\n\n"; rows = [];
    if (!cl.length) text += "No coupons yet.\n";
    for (j = 0; j < cl.length; j++) {
      text += "• <code>" + esc(cl[j].code) + "</code> — " + num(cl[j].pct, 0) + "% OFF\n";
      rows.push([B("🗑 " + cl[j].code, "/admin delcoupon " + j, "danger")]);
    }
    rows.push([B("➕ Add Coupon", "/admin addcoupon", "success")]);
    rows.push(AB);
    show(text, rows);
    return;
  }

  if (act === "prods") {
    ps = products(); rows = []; var row = [];
    for (i = 0; i < ps.length; i++) {
      row.push(B((ps[i].maint ? "🛠 " : "") + (ps[i].icon ? "" : "📦 ") + ps[i].name + " (" + stockOf(ps[i]) + ")", "/admin prod " + i, "primary", ps[i].icon ? String(ps[i].icon) : ""));
      if (row.length === 2) { rows.push(row); row = []; }
    }
    if (row.length) rows.push(row);
    rows.push([B("➕ Add Product", "/admin addprod", "success")]);
    rows.push(AB);
    show("📦 <b>Products</b>\n\nTap a product to manage plans & keys.", rows);
    return;
  }

  if (act === "prod") {
    i = parseInt(a[1], 10); p = products()[i];
    if (!p) { fail("❌ Product not found"); return; }
    text = "📦 <b>" + esc(p.name) + "</b>" + (p.maint ? "  🛠 <b>MAINTENANCE ON</b>" : "") + "\n\n"; rows = [];
    if (!p.plans.length) text += "No plans yet. Add one 👇\n";
    for (j = 0; j < p.plans.length; j++) {
      text += (j + 1) + ". " + esc(p.plans[j].label) + " — User ₹" + r2(p.plans[j].price) + " | Reseller " + (p.plans[j].rprice ? "₹" + r2(p.plans[j].rprice) : "—") + " — 🔑 " + (p.plans[j].keys || []).length + (p.plans[j].out ? " — 🚫 STOCK OUT" : "") + (p.plans[j].pid ? " — 🆔 PID " + esc(p.plans[j].pid) : "") + "\n";
      rows.push([B("🔑 Keys: " + p.plans[j].label, "/admin addkeys " + i + " " + j, "success"), B("🗑", "/admin delplan " + i + " " + j, "danger")]);
      rows.push([B("💰 User Price", "/admin editprice " + i + " " + j, "primary"), B("🏷 Reseller Price", "/admin editrprice " + i + " " + j, "primary")]);
      rows.push([B("🆔 PID: " + (p.plans[j].pid ? p.plans[j].pid : "Not set"), "/admin setpid " + i + " " + j, p.plans[j].pid ? "success" : "primary"), B("⏱ API Duration: " + (p.plans[j].apidur ? p.plans[j].apidur : "—"), "/admin setadur " + i + " " + j, "primary")]);
    }
    rows.push([B("✏️ Name", "/admin editname " + i, "primary"), B("📱 Device: " + (devOf(p.dev) ? devOf(p.dev).label : "ALL"), "/admin dev " + i, "primary")]);
    rows.push([B("🎨 Icon: " + (p.icon ? "SET ✅" : "NOT SET"), "/admin icon " + i, "primary")]);
    rows.push([B("📢 Update Channel: " + (p.upd_link ? "SET ✅" : "NOT SET"), "/admin updlink " + i, "primary")]);
    rows.push([B("➕ Add Plan", "/admin addplan " + i, "success"), B("🗑 Delete Product", "/admin delprod " + i, "danger")]);
    rows.push([B("Back", "/admin prods", "primary", "5240177683886784793")]);
    show(text, rows);
    return;
  }

  if (act === "addprod") {
    rows = [];
    for (j = 0; j < DEVICES.length; j++) rows.push([devBtn(DEVICES[j], "/admin pdev " + DEVICES[j].k)]);
    rows.push([B("🌐 All Devices", "/admin pdev all", "success")]);
    rows.push([B("➕ Add New Device", "/admin adddev addprod", "success"), B("🗑 Delete Device", "/admin devices addprod", "danger")]);
    rows.push(AB);
    show("➕ <b>Add Product</b>\n\n<b>Step 1:</b> Which device is this product for?", rows);
    return;
  }
  if (act === "pdev") {
    var pk = a[1] || "";
    if (pk !== "all" && !devOf(pk)) { fail("❌ Device not found"); return; }
    ask({ t: "addprod", stage: "name", dev: pk }, "➕ <b>Add Product</b>\n\n<b>Step 2:</b> Send the <b>product name</b>:", "/admin addprod");
    return;
  }
  if (act === "addplan") {
    i = parseInt(a[1], 10); if (!products()[i]) { fail("❌ Product not found"); return; }
    ask({ t: "addplan", i: i, stage: "label" }, "➕ <b>Add Plan</b>\n\nSend the <b>plan name</b> (e.g. <code>1 Day</code>):", "/admin prod " + i); return;
  }
  if (act === "addkeys") {
    i = parseInt(a[1], 10); j = parseInt(a[2], 10); p = products()[i];
    if (!p || !p.plans[j]) { fail("❌ Plan not found"); return; }
    ask({ t: "addkeys", i: i, j: j }, "🔑 <b>Add Keys</b> — " + esc(p.name) + " / " + esc(p.plans[j].label) + "\n\nSend keys, <b>one per line</b>:", "/admin prod " + i); return;
  }
  if (act === "delprod") {
    i = parseInt(a[1], 10); p = products()[i]; if (!p) { fail("❌ Product not found"); return; }
    show("🗑 Delete <b>" + esc(p.name) + "</b> with all plans and keys?\n\n<b>This cannot be undone.</b>",
      [[B("✅ Yes, delete", "/admin delprodok " + i, "danger"), B("❌ No", "/admin prod " + i, "primary")]]);
    return;
  }
  if (act === "delprodok") {
    i = parseInt(a[1], 10); ps = products(); if (!ps[i]) { fail("❌ Product not found"); return; }
    ps.splice(i, 1); saveProducts(ps);
    show("✅ Product deleted.", [[B("📦 Products", "/admin prods", "primary")]]);
    return;
  }

  if (act === "bal") {
    var op = a[1] === "sub" ? "sub" : "add";
    ask({ t: "bal", op: op, stage: "id" }, (op === "add" ? "💰 <b>Add Balance</b>" : "💸 <b>Remove Balance</b>") + "\n\nSend the user's <b>Telegram ID</b>:");
    return;
  }
  if (act === "bc") { ask({ t: "bc" }, "📢 <b>Broadcast</b>\n\nSend the message to deliver to <b>all users</b>.\n\nYou can send <b>text</b>, <b>photo</b>, <b>video</b>, <b>GIF</b>, <b>file</b> or <b>audio</b> (with a caption if you want)."); return; }

  if (act === "pay") {
    var gwv = function (k) { return CFG(k, ""); };
    var gwMask = function (v) { return v ? "••••" + String(v).slice(-4) : ""; };
    var gwLine = function (ok, text) { return (ok ? "✅ " : "❌ ") + text; };
    var cu = gwv("gw_create_url") || "https://galumodzgateway.site/api.php", vu = gwv("gw_verify_url") || "https://galumodzgateway.site/api.php", ak = gwv("gw_api_key");
    show("💳 <b>Payment Settings — Auto Gateway</b>\n\n" +
      gwLine(!!cu, "<b>Create Order URL</b>\n<code>" + esc(cu || "not set") + "</code>") + "\n\n" +
      gwLine(!!vu, "<b>Verify Order URL</b>\n<code>" + esc(vu || "not set") + "</code>") + "\n\n" +
      gwLine(!!ak, "<b>API Key</b>\n<code>" + esc(ak ? gwMask(ak) : "not set") + "</code>") + "\n\n" +
      (cu && vu && ak ? "<i>Gateway is ready. Add Balance QR will use it.</i>" : "<i>Set all 3 to enable Add Balance QR.</i>"),
      [
        [B("🔗 Set Create Order URL", "/admin set gw_create_url", "primary")],
        [B("🔎 Set Verify Order URL", "/admin set gw_verify_url", "primary")],
        [B("🔑 Set API Key", "/admin set gw_api_key", "success")],
        AB
      ]);
    return;
  }

  if (act === "set") {
    var setLabel = { update_btn: "All Update Channel - Button Name", update_link: "All Update Channel - Link", update_text: "All Update Channel - Text", howto_btn: "How To Use - Button Name", howto_link: "How-To Video Link", howto_text: "How-To Text", support_link: "Support Set - Username / Link", ref_bonus: "Refer And Price Set (₹)", gw_create_url: "Payment Gateway - Create Order URL", gw_verify_url: "Payment Gateway - Verify Order URL", gw_api_key: "Payment Gateway - API Key", rs_key: "Reseller API - API Key", rs_url: "Reseller API - API URL", proof_chat: "Proofs - Channel (@username or -100… ID)", proof_bot: "Proofs - Bot Username", upi_id: "UPI ID (for Add Balance QR)" };
    var skey = a[1] || "";
    if (!setLabel[skey]) { fail("❌ Unknown setting"); return; }
    var isNumKey = skey === "ref_bonus";
    var setBack = skey.indexOf("howto_") === 0 ? "/admin howto" : (skey.indexOf("update_") === 0 ? "/admin upd" : (skey.indexOf("gw_") === 0 || skey === "upi_id" ? "/admin pay" : (skey.indexOf("rs_") === 0 ? "/admin rsapi" : (skey.indexOf("proof_") === 0 ? "/admin proofs" : "/admin"))));
    ask({ t: "set", key: skey, label: setLabel[skey], isnum: isNumKey, back: setBack }, "⚙️ <b>" + setLabel[skey] + "</b>\n\nCurrent: <code>" + esc((skey === "gw_api_key" || skey === "rs_key") && CFG(skey, "") ? "••••" + String(CFG(skey, "")).slice(-4) : CFG(skey, skey === "ref_bonus" ? "2" : "—")) + "</code>\n\nSend the new value" + (isNumKey ? " (number, ₹)" : "") + ".\nSend <code>-</code> to clear it.", setBack);
    return;
  }

  if (act === "coadmin") {
    if (UID !== OWNER) { fail("❌ Owner only!"); return; }
    if (a[1] === "add" || a[1] === "rem") { ask({ t: "coadmin", op: a[1] }, "👮 Send the user's <b>Telegram ID</b> to " + (a[1] === "add" ? "make co-admin" : "remove from co-admins") + ":"); return; }
    show("👮 <b>Co-Admins</b>\n\nCo-admins can use the admin panel and approve top-ups.",
      [[B("➕ Add", "/admin coadmin add", "success"), B("➖ Remove", "/admin coadmin rem", "danger")], AB]);
    return;
  }

  fail("❌ Unknown admin action");
} catch (err) {
  Bot.sendMessage("⚠️ Admin error: " + err.message);
}
