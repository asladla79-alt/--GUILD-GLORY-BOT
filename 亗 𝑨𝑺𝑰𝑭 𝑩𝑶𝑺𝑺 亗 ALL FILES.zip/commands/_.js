/**#command
name: *
answer:
keyboard:
parse_mode: markdown
aliases:
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// ================= SHARED HELPERS (auto-included in every command) =================
function CFG(k, d) { var v = Bot.getProperty(k); return (v === null || typeof v === "undefined" || v === "") ? d : v; }
function num(v, d) { var n = Number(v); return isFinite(n) ? n : d; }
function r2(n) { return Math.round(num(n, 0) * 100) / 100; }
function esc(s) { return String(s === null || typeof s === "undefined" ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
function money(n) { return "₹" + r2(n).toFixed(2); }
function fmtDate(t) { if (!t) return "-"; return new Date(Number(t) + 19800000).toISOString().slice(0, 16).replace("T", " "); }

var OWNER = String(CFG("owner_id", "2049656553"));
var UID = String(user.telegramid);
var CID = chat.chatid;
var IS_NEW = false;

function isAdmin(id) { id = String(typeof id === "undefined" ? UID : id); return id === OWNER || !!Bot.getProperty("co_admin_" + id); }
function displayName() { var n = String((user.first_name || "") + " " + (user.last_name || "")).trim(); return n || user.username || "User"; }

// ---------- users ----------
function newUser(id) {
  return { id: String(id), name: displayName(), username: user.username || "", joined: Date.now(), bal: 0, spent: 0,
    order_count: 0, orders: [], topups: [], ref_by: null, ref_paid: false, refs: 0, ref_earn: 0, last_daily: 0, daily_total: 0 };
}
function loadUser(id) { var u = Bot.getProperty("u_" + id); return (u && typeof u === "object") ? u : null; }
function saveUser(u) { Bot.setProperty("u_" + u.id, u, "json"); }
function ensureUser() {
  var u = loadUser(UID);
  if (!u) {
    u = newUser(UID); IS_NEW = true;
    var list = Bot.getProperty("users");
    if (!Array.isArray(list)) list = [];
    list.push(UID);
    Bot.setProperty("users", list, "json");
  } else {
    u.name = displayName(); u.username = user.username || "";
  }
  saveUser(u);
  return u;
}

// ---------- conversation state ----------
function getState() { var s = User.getProperty("st"); return (s && typeof s === "object") ? s : null; }
function setState(o) { User.setProperty("st", o, "json"); }
function clearState() { User.setProperty("st", "", "string"); }

// ---------- products ----------
function products() { var p = Bot.getProperty("products"); return Array.isArray(p) ? p : []; }
function saveProducts(p) { Bot.setProperty("products", p, "json"); }
function stockOf(prod) { var n = 0; if (prod && prod.plans) for (var i = 0; i < prod.plans.length; i++) n += (prod.plans[i].keys || []).length; return n; }
function discPct() { return 0; }
function finalPrice(price, u) { return r2(num(price, 0)); }
function inc(k, by) { Bot.setProperty(k, String(r2(num(Bot.getProperty(k), 0) + by)), "string"); }

function linkOf(v) {
  v = String(v || "").trim(); if (!v) return "";
  if (/^https?:\/\//i.test(v)) return v;
  if (/^t\.me\//i.test(v)) return "https://" + v;
  return "https://t.me/" + v.replace(/^@/, "");
}

// ---------- telegram helpers ----------
function B(text, data, style, icon) { var b = { text: text, callback_data: data }; if (style) b.style = style; if (icon) b.icon_custom_emoji_id = String(icon); return b; }
function Ub(text, url, style, icon) { var b = { text: text, url: url }; if (style) b.style = style; if (icon) b.icon_custom_emoji_id = String(icon); return b; }
function qid() { if (!request) return null; return request.id || (request.callback_query && request.callback_query.id) || null; }
function isCb() { return !!(request && request.message && request.message.message_id && qid()); }
function ack(text, alert) {
  var q = qid(); if (!q) return;
  try { var o = { callback_query_id: String(q) }; if (text) { o.text = text; o.show_alert = !!alert; } Api.answerCallbackQuery(o); } catch (e) {}
}
function fail(text) { if (qid()) ack(text, true); else Api.sendMessage({ chat_id: CID, text: text }); }
function sendTo(id, text, rows) {
  var o = { chat_id: id, text: text, parse_mode: "HTML", disable_web_page_preview: true };
  if (rows) o.reply_markup = JSON.stringify({ inline_keyboard: rows });
  try { Api.sendMessage(o); } catch (e) {}
}
// Edit the tapped message (or send a new one when called from plain text / a photo message)
function show(text, rows) {
  var markup = JSON.stringify({ inline_keyboard: rows || [] });
  ack();
  if (isCb()) {
    var m = request.message;
    if (m.photo || m.video || m.document) {
      try { Api.deleteMessage({ chat_id: CID, message_id: m.message_id }); } catch (e) {}
      Api.sendMessage({ chat_id: CID, text: text, parse_mode: "HTML", disable_web_page_preview: true, reply_markup: markup });
    } else {
      Api.editMessageText({ chat_id: CID, message_id: m.message_id, text: text, parse_mode: "HTML", disable_web_page_preview: true, reply_markup: markup });
    }
  } else {
    Api.sendMessage({ chat_id: CID, text: text, parse_mode: "HTML", disable_web_page_preview: true, reply_markup: markup });
  }
}
var BACK = [B("Back", "/back", "primary", "5240177683886784793")];
// ---------- global Maintenance Mode (bot off for all users; admins bypass) ----------
if (CFG("maint_mode", "") === "1" && !isAdmin()) {
  try {
    var mmLink = linkOf(CFG("update_link", ""));
    show("🛠 <b>Bot Under Maintenance</b>\n\nThe bot is currently under maintenance. Please check back later — sorry for the inconvenience!",
      mmLink ? [[{ text: "Check Update", url: mmLink, style: "primary" }]] : []);
  } catch (e) {}
  return;
}


// ---------- add-balance look & feel (shared by /addfund, /kp and the typed-amount handler) ----------
var MAXT = 50000;
var ICON_BAG = "6210859306602995217";   // money-bag premium emoji
var ICON_BACK = "5240177683886784793";  // back-arrow premium emoji
var RULE = "━━━━━━━━━━━━━━━━━━━━━━";
function fmtInt(n) { return String(Math.floor(num(n, 0))).replace(/\B(?=(\d{3})+(?!\d))/g, ","); }
function bagEmoji() { return "<tg-emoji emoji-id=\"" + ICON_BAG + "\">💰</tg-emoji>"; }
var GEN_TEXT = "<blockquote><tg-emoji emoji-id=\"6219547832169273793\">💳</tg-emoji> <b>ɢᴇɴᴇʀᴀᴛɪɴɢ ꜱᴇᴄᴜʀᴇ ǫʀ</b></blockquote>\n\n" +
  "<blockquote><tg-emoji emoji-id=\"6159057628736528371\">⏳</tg-emoji> ᴄʀᴇᴀᴛɪɴɢ ʏᴏᴜʀ ᴘᴀʏᴍᴇɴᴛ ᴏʀᴅᴇʀ...\n<tg-emoji emoji-id=\"5449913031578379785\">🛡️</tg-emoji> ᴘʟᴇᴀꜱᴇ ᴡᴀɪᴛ ᴀ ꜰᴇᴡ ꜱᴇᴄᴏɴᴅꜱ</blockquote>";
function tgE(id, fb) { return "<tg-emoji emoji-id=\"" + id + "\">" + fb + "</tg-emoji>"; }
function msgIdOf(res) {
  try {
    if (!res) return null;
    if (res.message_id) return res.message_id;
    if (res.result && res.result.message_id) return res.result.message_id;
  } catch (e) {}
  return null;
}
// Shows "GENERATING SECURE QR", sends the UPI QR, then removes the "generating" notice.
// mid = message id to turn into the notice (keypad / menu message); null = send a fresh notice.
function createOrder(amt, mid) {
  var upi = CFG("upi_id", ""), pn = CFG("upi_name", CFG("store_name", "Store"));
  var empty = JSON.stringify({ inline_keyboard: [] });
  if (mid) {
    try { Api.editMessageText({ chat_id: CID, message_id: mid, text: GEN_TEXT, parse_mode: "HTML", reply_markup: empty }); } catch (e) {}
  } else {
    try { mid = msgIdOf(Api.sendMessage({ chat_id: CID, text: GEN_TEXT, parse_mode: "HTML" })); } catch (e) {}
  }
  var uri = "upi://pay?pa=" + upi + "&pn=" + encodeURIComponent(pn) + "&am=" + amt + "&cu=INR&tn=" + encodeURIComponent("Topup " + UID);
  var qr = "https://api.qrserver.com/v1/create-qr-code/?size=500x500&data=" + encodeURIComponent(uri);
  setState({ t: "dep_proof", amount: amt });
  var cap = bagEmoji() + " <b>PAY ₹" + fmtInt(amt) + " — UPI PAY</b>\n" + RULE + "\n" +
    "<b>AMOUNT</b> | ₹" + fmtInt(amt) + "\n" +
    "<b>UPI ID</b> | <code>" + esc(upi) + "</code>\n" + RULE + "\n" +
    "1️⃣ <i>Scan the QR or pay to the UPI ID.</i>\n" +
    "2️⃣ <i>After paying, send the</i> <b>PAYMENT SCREENSHOT</b> <i>(or UTR number) here.</i>";
  Api.sendPhoto({
    chat_id: CID, photo: qr, parse_mode: "HTML", caption: cap,
    reply_markup: JSON.stringify({ inline_keyboard: [[B("Cancel", "/back", "danger", ICON_BACK)]] })
  });
  if (mid) { try { Api.deleteMessage({ chat_id: CID, message_id: mid }); } catch (e) {} }
}
// ---------- device types (premium icon ids: put the custom emoji id in "icon", else the plain emoji in "fb" is used) ----------
var DEVICES = loadDevices();
function loadDevices() {
  var d = Bot.getProperty("devices");
  if (Array.isArray(d)) return d;
  return [
  { k: "anr", label: "ANDROID NONROOT", icon: "5929253286145166951", fb: "🤖" },
  { k: "ar",  label: "ANDROID ROOT",    icon: "5929253286145166951", fb: "🤖" },
  { k: "pc",  label: "PC / COMPUTER",   icon: "5440784572511972384", fb: "💻" },
  { k: "ios", label: "IOS / IPHONE",    icon: "5262960432397689651", fb: "🍎" }
];
}
function saveDevices(arr) { Bot.setProperty("devices", arr, "json"); DEVICES = arr; }
function devOf(k) { for (var d = 0; d < DEVICES.length; d++) if (DEVICES[d].k === k) return DEVICES[d]; return null; }
function devBtn(d, data) { return B(d.icon ? d.label : d.fb + " " + d.label, data, "primary", d.icon); }
// ================= MAIN MENU (same layout as the reference screenshot) =================
function menuText(u, isNew) {
  var store = esc(CFG("store_name", "亗 𝑨𝑺𝑰𝑭 𝑩𝑶𝑺𝑺 亗 𝗦𝗛𝗢𝗣"));
  var LINE = "────────────────────────";
  var PAD = new Array(29).join("\u2800"); // invisible filler: pins the bubble to one fixed width (change 29 to make wider/narrower)
  return "<tg-emoji emoji-id=\"6093562529978522804\">🛒</tg-emoji> ─── <b>" + store + "</b> ─── <tg-emoji emoji-id=\"6093562529978522804\">🛒</tg-emoji>\n\n" +
    "<tg-emoji emoji-id=\"6057728771719435723\">👑</tg-emoji> <i>Welcome,</i> <b><i>" + esc(u.name) + "</i></b>\n\n" +
    "<tg-emoji emoji-id=\"6208671660715809463\">🔼</tg-emoji> ─── <b>STORE HIGHLIGHTS</b> ─── <tg-emoji emoji-id=\"6208671660715809463\">🔼</tg-emoji>\n\n" +
    "<blockquote>" +
    "<tg-emoji emoji-id=\"5472057595193743789\">🎮</tg-emoji> Premium Game Keys\n" +
    "<tg-emoji emoji-id=\"5368554037320900698\">🟢</tg-emoji> Instant Delivery 24/7\n" +
    "<tg-emoji emoji-id=\"6165821484968188344\">1️⃣</tg-emoji> 100% Secure Payment\n" +
    "<tg-emoji emoji-id=\"6093377734715642495\">🏷</tg-emoji> Best Prices Guaranteed\n" +
    "<tg-emoji emoji-id=\"5447419223242449630\">🇮🇳</tg-emoji> Safe And Trusted\n" +
    "<tg-emoji emoji-id=\"5235570365094188078\">✅</tg-emoji> Professional Support" +
    "</blockquote>\n\n" +
    LINE + "\n" +
    "<tg-emoji emoji-id=\"6210859306602995217\">💰</tg-emoji> <b>Wallet Balance:</b> " + money(u.bal) + "\n" +
    LINE + "\n" + PAD + "\n" +
    "<tg-emoji emoji-id=\"5231102735817918643\">🔥</tg-emoji> <i>Tap Shop Now to Start!</i>";
}
// How To Use Bot: direct link button (opens the video/link straight away); falls back to /howto text if no link is set
function howtoBtn() {
  var l = linkOf(CFG("howto_link", ""));
  var ic = "5427158904729513162";
  var hb = CFG("howto_btn", "How To Use");
  return l ? Ub(hb, l, "primary", ic) : B(hb, "/howto", "primary", ic);
}
function menuKb() {
  return [
    [B("Shop Now", "/buy", "danger", "6093562529978522804")],
    [B(CFG("update_btn", "Check Update"), "/update", "success", "5255741073409452371"), B("Add Balance", "/addfund", "primary", "6210859306602995217")],
    [B("My Profile", "/profile", "success", "5258362837411045098")],
    [B("Refer And Earn", "/refer", "success", "5260450573768990626"), howtoBtn()],
    [B("Support", "/support", "danger", "5253742260054409879"), B("Daily Gift", "/daily", "success", "5442939099906325301")]
  ];
}
function showMenu(u, isNew) { show(menuText(u, isNew), menuKb()); }

// Catches every message that is not a registered command:
//  - top-up wizard (amount -> payment proof)
//  - admin wizards (add product / plan / keys / balance / broadcast / settings / co-admin)
//  - anything else -> main menu
try {
  var txt = String(message || (request && (request.text || request.caption)) || "").trim();
  var photo = (request && request.photo && request.photo.length) ? request.photo[request.photo.length - 1].file_id : null;
  var st = getState();
  var u = ensureUser();
  var CANCEL = [[B("Back to Menu", "/back", "primary", "5240177683886784793")]];

  if (!st) { showMenu(u, IS_NEW); return; }

  // ---------------- user: top-up wizard ----------------
  if (st.t === "dep_amount") {
    var amt = Math.floor(num(txt.replace(/[^\d.]/g, ""), 0));
    var min = num(CFG("min_topup", 10), 10);
    if (!txt || amt < min || amt > MAXT) {
      Api.sendMessage({ chat_id: CID, text: "⚠️ Send a valid amount between ₹" + fmtInt(min) + " and ₹" + fmtInt(MAXT) + ".", reply_markup: JSON.stringify({ inline_keyboard: [[B("Back", "/addfund", "danger", ICON_BACK)]] }) });
      return;
    }
    createOrder(amt, null);
    return;
  }

  if (st.t === "dep_proof") {
    if (!photo && txt.length < 4) {
      Api.sendMessage({ chat_id: CID, text: "📸 Please send the payment <b>screenshot</b> or the <b>UTR number</b>.", parse_mode: "HTML", reply_markup: JSON.stringify({ inline_keyboard: [[B("Cancel", "/back", "danger", "5240177683886784793")]] }) });
      return;
    }
    var id = Math.floor(num(Bot.getProperty("tp_counter"), 0)) + 1;
    Bot.setProperty("tp_counter", String(id), "string");
    var tp = { id: id, uid: UID, name: u.name, amount: st.amount, proof: photo ? "" : txt, photo: photo, status: "pending", t: Date.now() };
    Bot.setProperty("tp_" + id, tp, "json");
    u.topups.push({ id: id, t: Date.now(), amount: st.amount, status: "pending" });
    if (u.topups.length > 50) u.topups = u.topups.slice(-50);
    saveUser(u);
    clearState();

    var cap = "💳 <b>New Top-up #" + id + "</b>\n👤 " + esc(u.name) + (u.username ? " (@" + esc(u.username) + ")" : "") + " — <code>" + UID + "</code>\n💰 Amount: <b>" + money(st.amount) + "</b>" + (tp.proof ? "\n🧾 UTR/Note: <code>" + esc(tp.proof) + "</code>" : "");
    var kb = JSON.stringify({ inline_keyboard: [[B("✅ Approve", "/tp ok " + id, "success"), B("❌ Reject", "/tp no " + id, "danger")]] });
    try {
      if (photo) Api.sendPhoto({ chat_id: OWNER, photo: photo, caption: cap, parse_mode: "HTML", reply_markup: kb });
      else Api.sendMessage({ chat_id: OWNER, text: cap, parse_mode: "HTML", reply_markup: kb });
    } catch (e) {}
    Api.sendMessage({ chat_id: CID, text: "✅ <b>Request #" + id + " submitted!</b>\n\n💰 " + money(st.amount) + " will be added right after admin verifies your payment.", parse_mode: "HTML", reply_markup: JSON.stringify({ inline_keyboard: CANCEL }) });
    return;
  }

  // ---------------- user: coupon code ----------------
  if (st.t === "coupon") {
    var code = txt.toUpperCase().replace(/\s+/g, "");
    var cl = Bot.getProperty("coupons"); cl = Array.isArray(cl) ? cl : [];
    var hit = null;
    for (var cq = 0; cq < cl.length; cq++) if (cl[cq].code === code) hit = cl[cq];
    if (!hit) {
      Api.sendMessage({ chat_id: CID, text: "❌ Invalid coupon code. Send a valid code or go back.", reply_markup: JSON.stringify({ inline_keyboard: [[B("Back", "/prod " + st.i, "danger", ICON_BACK)]] }) });
      return;
    }
    clearState(); User.setProperty("cp", hit.code, "string");
    Api.sendMessage({ chat_id: CID, text: "✅ Coupon <b>" + esc(hit.code) + "</b> applied — <b>" + num(hit.pct, 0) + "% OFF</b>", parse_mode: "HTML", reply_markup: JSON.stringify({ inline_keyboard: [[B("✅ Continue", "/prod " + st.i, "success")]] }) });
    return;
  }

  // ---------------- user: UPI product order -> payment proof ----------------
  if (st.t === "buy_proof") {
    if (!photo && txt.length < 4) {
      Api.sendMessage({ chat_id: CID, text: "📸 Please send the payment <b>screenshot</b> or the <b>UTR number</b>.", parse_mode: "HTML", reply_markup: JSON.stringify({ inline_keyboard: [[B("Cancel", "/prod " + st.i, "danger", "5240177683886784793")]] }) });
      return;
    }
    var bid = Math.floor(num(Bot.getProperty("tp_counter"), 0)) + 1;
    Bot.setProperty("tp_counter", String(bid), "string");
    var btp = { id: bid, kind: "buy", uid: UID, name: u.name, amount: st.amount, i: st.i, j: st.j, pname: st.pname, plabel: st.plabel, proof: photo ? "" : txt, photo: photo, status: "pending", t: Date.now() };
    Bot.setProperty("tp_" + bid, btp, "json");
    clearState();
    var bcap = "🛒 <b>New UPI Order #" + bid + "</b>\n👤 " + esc(u.name) + (u.username ? " (@" + esc(u.username) + ")" : "") + " — <code>" + UID + "</code>\n📦 " + esc(st.pname) + " — " + esc(st.plabel) + "\n💰 Amount: <b>" + money(st.amount) + "</b>" + (btp.proof ? "\n🧾 UTR/Note: <code>" + esc(btp.proof) + "</code>" : "");
    var bkb = JSON.stringify({ inline_keyboard: [[B("✅ Approve & Deliver", "/tp ok " + bid, "success"), B("❌ Reject", "/tp no " + bid, "danger")]] });
    try {
      if (photo) Api.sendPhoto({ chat_id: OWNER, photo: photo, caption: bcap, parse_mode: "HTML", reply_markup: bkb });
      else Api.sendMessage({ chat_id: OWNER, text: bcap, parse_mode: "HTML", reply_markup: bkb });
    } catch (e) {}
    Api.sendMessage({ chat_id: CID, text: "✅ <b>Order #" + bid + " submitted!</b>\n\n📦 " + esc(st.pname) + " — " + esc(st.plabel) + "\n💰 " + money(st.amount) + "\n\nYour key will be delivered here right after admin verifies your payment.", parse_mode: "HTML", reply_markup: JSON.stringify({ inline_keyboard: CANCEL }) });
    return;
  }

  // ---------------- admin wizards ----------------
  if (!isAdmin()) { clearState(); showMenu(u, false); return; }
  var done = function (msg, rows) { clearState(); sendTo(CID, msg, rows || [[B("Admin Panel", "/admin", "primary", "5240177683886784793")]]); };

  if (st.t === "updlink") {
    var pul = products();
    if (!pul[st.i]) { done("❌ Product no longer exists."); return; }
    if (txt === "-" || txt === "") { delete pul[st.i].upd_link; saveProducts(pul); done("✅ Update channel link cleared. This product will use the All Update Channel link.", [[B("📦 Product", "/admin prod " + st.i, "primary")]]); return; }
    var ulink = linkOf(txt);
    if (!/^https?:\/\/\S+$/i.test(ulink)) { sendTo(CID, "⚠️ Send a valid link (https://t.me/... or @username)."); return; }
    pul[st.i].upd_link = ulink; saveProducts(pul);
    done("✅ Update channel link set for <b>" + esc(pul[st.i].name) + "</b>:\n" + esc(ulink), [[B("📦 Product", "/admin prod " + st.i, "primary")]]);
    return;
  }

  if (st.t === "prodicon") {
    var pps = products();
    if (!pps[st.i]) { done("❌ Product no longer exists."); return; }
    if (txt === "-") { delete pps[st.i].icon; saveProducts(pps); done("✅ Icon removed.", [[B("📦 Product", "/admin prod " + st.i, "primary")]]); return; }
    var ents = (request && (request.entities || request.caption_entities)) || [], cem = "";
    for (var ee = 0; ee < ents.length; ee++) if (ents[ee].type === "custom_emoji" && ents[ee].custom_emoji_id) { cem = String(ents[ee].custom_emoji_id); break; }
    if (!cem) { var mm = txt.match(/\d{10,25}/); if (mm) cem = mm[0]; }
    if (!cem) { sendTo(CID, "⚠️ Send a <b>premium emoji</b> (or its numeric emoji ID). Send <code>-</code> to remove the icon."); return; }
    pps[st.i].icon = cem; saveProducts(pps);
    done("✅ Icon set for <b>" + esc(pps[st.i].name) + "</b> " + tgE(cem, "🛒"), [[B("📦 Product", "/admin prod " + st.i, "primary")]]);
    return;
  }

  if (st.t === "addcoupon") {
    if (st.stage === "code") {
      var cc = txt.toUpperCase().replace(/\s+/g, "");
      if (!/^[A-Z0-9]{3,20}$/.test(cc)) { sendTo(CID, "⚠️ Code must be 3–20 letters/numbers (no spaces)."); return; }
      setState({ t: "addcoupon", stage: "pct", code: cc });
      sendTo(CID, "🎟 Code <b>" + cc + "</b>\n\nNow send the <b>discount %</b> (1–90):");
      return;
    }
    var pct = Math.floor(num(txt, 0));
    if (pct < 1 || pct > 90) { sendTo(CID, "⚠️ Send a number between 1 and 90."); return; }
    var cps = Bot.getProperty("coupons"); cps = Array.isArray(cps) ? cps : [];
    var found = false;
    for (var cx = 0; cx < cps.length; cx++) if (cps[cx].code === st.code) { cps[cx].pct = pct; found = true; }
    if (!found) cps.push({ code: st.code, pct: pct });
    Bot.setProperty("coupons", cps, "json");
    done("✅ Coupon <b>" + st.code + "</b> — " + pct + "% OFF saved.", [[B("🎟 Coupons", "/admin coupons", "primary")]]);
    return;
  }

  if (st.t === "adddev" || st.t === "devicon") {
    // read a premium emoji (custom_emoji entity or numeric id) from the message
    var dEnts = (request && (request.entities || request.caption_entities)) || [], dEmoji = "";
    for (var de = 0; de < dEnts.length; de++) if (dEnts[de].type === "custom_emoji" && dEnts[de].custom_emoji_id) { dEmoji = String(dEnts[de].custom_emoji_id); break; }
    if (!dEmoji) { var dmm = txt.match(/\d{10,25}/); if (dmm) dEmoji = dmm[0]; }
    var skip = (txt === "-");

    if (st.t === "adddev" && st.stage !== "icon") {
      if (!txt) { sendTo(CID, "⚠️ Send the device name as text."); return; }
      var dname0 = txt.toUpperCase().slice(0, 30);
      setState({ t: "adddev", stage: "icon", ret: st.ret, name: dname0 });
      sendTo(CID, "🎨 <b>Premium emoji</b> for <b>" + esc(dname0) + "</b>?\n\nSend a <b>premium emoji</b> now, or send <code>-</code> to skip.");
      return;
    }

    if (st.t === "adddev") {
      if (!skip && !dEmoji) { sendTo(CID, "⚠️ Send a <b>premium emoji</b>, or <code>-</code> to skip."); return; }
      var dls = loadDevices();
      dls.push({ k: "d" + Date.now().toString(36), label: st.name, icon: skip ? "" : dEmoji, fb: "📱" });
      saveDevices(dls);
      var dtxt = "✅ Device <b>" + esc(st.name) + "</b> added" + (skip ? "." : " with premium emoji " + tgE(dEmoji, "📱") + ".");
      if (st.ret === "addprod") {
        done(dtxt + "\n\nAb Add Product mein ye device select kar sakte ho 👇", [[B("➕ Continue Add Product", "/admin addprod", "success")], [B("Admin Panel", "/admin", "primary", "5240177683886784793")]]);
      } else {
        done(dtxt, [[B("📱 Devices", "/admin devices", "primary")], [B("Admin Panel", "/admin", "primary", "5240177683886784793")]]);
      }
      return;
    }

    // st.t === "devicon": change premium emoji of an existing device
    var dl2 = loadDevices(), found2 = false;
    for (var dx = 0; dx < dl2.length; dx++) if (dl2[dx].k === st.k) { found2 = true; dl2[dx].icon = skip ? "" : dEmoji; }
    if (!found2) { done("❌ Device no longer exists."); return; }
    if (!skip && !dEmoji) { setState(st); sendTo(CID, "⚠️ Send a <b>premium emoji</b>, or <code>-</code> to remove it."); return; }
    saveDevices(dl2);
    done("✅ Device emoji " + (skip ? "removed." : "updated to " + tgE(dEmoji, "📱") + "."), [[B("📱 Devices", "/admin devices", "primary")]]);
    return;
  }

  if (st.t === "addprod") {
    if (st.stage === "name") {
      if (!txt) { sendTo(CID, "⚠️ Send the product name as text."); return; }
      var pnm = txt.slice(0, 40);
      setState({ t: "addprod", stage: "plan", dev: st.dev, name: pnm });
      sendTo(CID, "📝 <b>Step 3:</b> Send the <b>plan name</b> for <b>" + esc(pnm) + "</b> (e.g. <code>1 Day</code>):");
      return;
    }
    if (st.stage === "plan") {
      if (!txt) { sendTo(CID, "⚠️ Send the plan name as text."); return; }
      setState({ t: "addprod", stage: "price", dev: st.dev, name: st.name, label: txt.slice(0, 30) });
      sendTo(CID, "💵 <b>Step 4:</b> Send the <b>User price</b> in ₹ for <b>" + esc(txt.slice(0, 30)) + "</b>:");
      return;
    }
    if (st.stage === "price") {
      var pprice = num(txt, 0);
      if (pprice <= 0) { sendTo(CID, "⚠️ Send a valid User price (number)."); return; }
      setState({ t: "addprod", stage: "rprice", dev: st.dev, name: st.name, label: st.label, price: r2(pprice) });
      sendTo(CID, "🏷 <b>Step 5:</b> Send the <b>Reseller price</b> in ₹ for <b>" + esc(st.label) + "</b>:");
      return;
    }
    var rprice = num(txt, 0);
    if (rprice <= 0) { sendTo(CID, "⚠️ Send a valid Reseller price (number)."); return; }
    var pps2 = products();
    var newp = { name: st.name, plans: [{ label: st.label, price: r2(st.price), rprice: r2(rprice), keys: [] }] };
    if (st.dev && st.dev !== "all") newp.dev = st.dev;
    pps2.push(newp); saveProducts(pps2);
    var pnx = pps2.length - 1;
    var pdev = (st.dev && st.dev !== "all" && devOf(st.dev)) ? devOf(st.dev).label : "🌐 ALL DEVICES";
    done("✅ Product <b>" + esc(st.name) + "</b> added.\n📱 Device: <b>" + esc(pdev) + "</b>\n📝 Plan: <b>" + esc(st.label) + "</b>\n💵 User price: <b>" + money(st.price) + "</b>\n🏷 Reseller price: <b>" + money(rprice) + "</b>\n\nNow add keys 👇",
      [[B("🔑 Add Keys", "/admin addkeys " + pnx + " 0", "success")],
       [B("📦 Manage Products", "/admin prods", "primary")],
       [B("Admin Panel", "/admin", "primary", "5240177683886784793")]]);
    return;
  }

  if (st.t === "editname") {
    var enp = products();
    if (!enp[st.i]) { done("❌ Product no longer exists."); return; }
    enp[st.i].name = txt.slice(0, 40); saveProducts(enp);
    done("✅ Name updated to <b>" + esc(enp[st.i].name) + "</b>.", [[B("📦 Product", "/admin prod " + st.i, "primary")]]);
    return;
  }

  if (st.t === "setpid" || st.t === "setadur") {
    var spp = products();
    if (!spp[st.i] || !spp[st.i].plans[st.j]) { done("❌ Plan no longer exists."); return; }
    if (!txt) { sendTo(CID, "⚠️ Send the value as text, or - to clear."); return; }
    var fld = st.t === "setpid" ? "pid" : "apidur";
    var nv = txt === "-" ? "" : (fld === "pid" ? txt.replace(/\s+/g, "").slice(0, 40) : txt.slice(0, 30));
    if (nv) spp[st.i].plans[st.j][fld] = nv; else delete spp[st.i].plans[st.j][fld];
    saveProducts(spp);
    done("✅ " + (fld === "pid" ? "PID" : "API Duration") + " " + (nv ? "set to <code>" + esc(nv) + "</code>." : "cleared."), [[B("📦 Product", "/admin prod " + st.i, "primary")]]);
    return;
  }

  if (st.t === "editprice" || st.t === "editrprice") {
    var epp = products();
    if (!epp[st.i] || !epp[st.i].plans[st.j]) { done("❌ Plan no longer exists."); return; }
    var epr = num(txt, 0);
    if (epr <= 0) { sendTo(CID, "⚠️ Send a valid price (number)."); return; }
    if (st.t === "editprice") epp[st.i].plans[st.j].price = r2(epr); else epp[st.i].plans[st.j].rprice = r2(epr);
    saveProducts(epp);
    done("✅ " + (st.t === "editprice" ? "User" : "Reseller") + " price updated to <b>" + money(epr) + "</b>.", [[B("📦 Product", "/admin prod " + st.i, "primary")]]);
    return;
  }

  if (st.t === "resup" || st.t === "resrem") {
    var rid = txt.replace(/\D/g, "");
    if (!rid) { sendTo(CID, "⚠️ Send a numeric Telegram ID."); return; }
    var ru = loadUser(rid);
    if (!ru) { done("❌ User not found. They must start the bot once first."); return; }
    if (st.t === "resup") {
      Bot.setProperty("reseller_" + rid, "1", "string");
      sendTo(rid, "🎉 <b>Congrats!</b> You are now a <b>Reseller</b>. Reseller prices will apply to your purchases.");
      done("✅ <b>" + esc(ru.name) + "</b> is now a Reseller.");
    } else {
      Bot.setProperty("reseller_" + rid, "", "string");
      sendTo(rid, "ℹ️ Your Reseller access has been removed. Normal prices will apply.");
      done("✅ <b>" + esc(ru.name) + "</b> removed from Resellers.");
    }
    return;
  }

  if (st.t === "addplan") {
    if (st.stage === "label") {
      if (!txt) { sendTo(CID, "⚠️ Send the plan name as text."); return; }
      setState({ t: "addplan", i: st.i, stage: "price", label: txt.slice(0, 30) });
      sendTo(CID, "💵 Now send the <b>User price</b> in ₹ for <b>" + esc(txt.slice(0, 30)) + "</b>:");
      return;
    }
    if (st.stage === "price") {
      var price = num(txt, 0);
      if (price <= 0) { sendTo(CID, "⚠️ Send a valid User price (number)."); return; }
      setState({ t: "addplan", i: st.i, stage: "rprice", label: st.label, price: r2(price) });
      sendTo(CID, "🏷 Now send the <b>Reseller price</b> in ₹ for <b>" + esc(st.label) + "</b>:");
      return;
    }
    if (st.stage === "rprice") {
      var rp0 = num(txt, 0);
      if (rp0 <= 0) { sendTo(CID, "⚠️ Send a valid Reseller price (number)."); return; }
      setState({ t: "addplan", i: st.i, stage: "pid", label: st.label, price: st.price, rprice: r2(rp0) });
      sendTo(CID, "🆔 Last step: send the <b>PID</b> (Reseller API CODE) for <b>" + esc(st.label) + "</b> to get keys automatically.\n\nSend <code>-</code> to skip (manual keys only).");
      return;
    }
    var rp = num(st.rprice, 0);
    var pidv = txt === "-" ? "" : txt.replace(/\s+/g, "").slice(0, 40);
    var ps2 = products(); if (!ps2[st.i]) { done("❌ Product no longer exists."); return; }
    var npl = { label: st.label, price: r2(st.price), rprice: r2(rp), keys: [] }; if (pidv) npl.pid = pidv;
    ps2[st.i].plans.push(npl); saveProducts(ps2);
    done("✅ Plan <b>" + esc(st.label) + "</b> added.\n💵 User price: <b>" + money(st.price) + "</b>\n🏷 Reseller price: <b>" + money(rp) + "</b>\n🆔 PID: <b>" + (pidv ? esc(pidv) + "</b> (auto keys)" : "not set</b>") + "\nNow add keys 👇",
      [[B("🔑 Add Keys", "/admin addkeys " + st.i + " " + (ps2[st.i].plans.length - 1), "success")], [B("📦 Product", "/admin prod " + st.i, "primary")]]);
    return;
  }

  if (st.t === "addkeys") {
    var lines = txt.split(/\r?\n/).map(function (x) { return x.trim(); }).filter(function (x) { return x; });
    if (!lines.length) { sendTo(CID, "⚠️ Send at least one key (one per line)."); return; }
    var ps3 = products(); var pl = ps3[st.i] && ps3[st.i].plans[st.j];
    if (!pl) { done("❌ Plan no longer exists."); return; }
    pl.keys = (pl.keys || []).concat(lines); saveProducts(ps3);
    done("✅ <b>" + lines.length + "</b> key(s) added.\n🔑 Stock now: <b>" + pl.keys.length + "</b>", [[B("📦 Product", "/admin prod " + st.i, "primary")]]);
    return;
  }

  if (st.t === "bal") {
    if (st.stage === "id") {
      var tid = txt.replace(/\D/g, "");
      var tu = tid && loadUser(tid);
      if (!tu) { sendTo(CID, "⚠️ User not found. Send a valid Telegram ID of a user who has started the bot."); return; }
      setState({ t: "bal", op: st.op, stage: "amt", uid: tid });
      sendTo(CID, "👤 <b>" + esc(tu.name) + "</b> — balance " + money(tu.bal) + "\n\nSend the amount in ₹:");
      return;
    }
    var a2 = num(txt, 0);
    if (a2 <= 0) { sendTo(CID, "⚠️ Send a valid amount."); return; }
    var t2 = loadUser(st.uid);
    if (!t2) { done("❌ User not found."); return; }
    if (st.op === "sub") {
      if (t2.bal < a2) { done("❌ User only has " + money(t2.bal) + "."); return; }
      t2.bal = r2(t2.bal - a2);
    } else t2.bal = r2(t2.bal + a2);
    saveUser(t2);
    sendTo(t2.id, (st.op === "add" ? "💰 <b>" + money(a2) + " added</b> to your wallet by admin." : "💸 <b>" + money(a2) + " deducted</b> from your wallet by admin.") + "\n🌑 Balance: <b>" + money(t2.bal) + "</b>");
    done("✅ Done. " + esc(t2.name) + " new balance: <b>" + money(t2.bal) + "</b>");
    return;
  }

  if (st.t === "bc") {
    // pick the media the admin sent: photo / video / GIF / file / audio / voice
    var bm = null;
    if (photo) bm = { api: "sendPhoto", key: "photo", id: photo };
    else if (request && request.video) bm = { api: "sendVideo", key: "video", id: request.video.file_id };
    else if (request && request.animation) bm = { api: "sendAnimation", key: "animation", id: request.animation.file_id };
    else if (request && request.document) bm = { api: "sendDocument", key: "document", id: request.document.file_id };
    else if (request && request.audio) bm = { api: "sendAudio", key: "audio", id: request.audio.file_id };
    else if (request && request.voice) bm = { api: "sendVoice", key: "voice", id: request.voice.file_id };
    if (!txt && !bm) { sendTo(CID, "⚠️ Send text, photo, video, GIF, file or audio."); return; }
    var all = Bot.getProperty("users"); all = Array.isArray(all) ? all : [];
    var cap = txt.slice(0, 1024), rest = txt.length > 1024 ? txt.slice(1024) : "";
    var okc = 0;
    for (var k = 0; k < all.length; k++) {
      try {
        if (bm) {
          var bo = { chat_id: all[k] }; bo[bm.key] = bm.id; if (cap) bo.caption = cap;
          Api[bm.api](bo);
          if (rest) Api.sendMessage({ chat_id: all[k], text: rest });
        } else {
          Api.sendMessage({ chat_id: all[k], text: txt });
        }
        okc++;
      } catch (e) {}
    }
    done("📢 Broadcast sent to <b>" + okc + "</b> of <b>" + all.length + "</b> users.");
    return;
  }

  if (st.t === "set") {
    if (!txt) { sendTo(CID, "⚠️ Send the value as text."); return; }
    var val = txt === "-" ? "" : txt;
    if (st.key === "proof_chat" && val !== "") {
      var pcm = val.match(/t\.me\/([A-Za-z0-9_]+)/i);
      if (pcm) val = "@" + pcm[1]; else if (/^[A-Za-z][A-Za-z0-9_]{3,}$/.test(val)) val = "@" + val;
      if (!/^(@[A-Za-z][A-Za-z0-9_]{3,}|-?\d{5,})$/.test(val)) { sendTo(CID, "⚠️ Send the channel <b>@username</b> or its numeric ID (like <code>-1001234567890</code>)."); return; }
    }
    if (st.key === "proof_bot" && val !== "") {
      val = val.replace(/^https?:\/\/t\.me\//i, "").replace(/^@/, "").replace(/[\/?].*$/, "");
      if (!/^[A-Za-z][A-Za-z0-9_]{3,}$/.test(val)) { sendTo(CID, "⚠️ Send a valid bot username (like <code>Galu_Modz_Shop_Bot</code>)."); return; }
    }
    if (((st.key.indexOf("gw_") === 0 && st.key !== "gw_api_key") || st.key === "rs_url") && val !== "" && !/^https:\/\/\S+$/i.test(val)) { sendTo(CID, "⚠️ Send a valid https:// URL."); return; }
    if (st.isnum && val !== "" && !(num(val, NaN) >= 0)) { sendTo(CID, "⚠️ Send a valid number."); return; }
    Bot.setProperty(st.key, val, "string");
    if (st.key === "rs_key") { try { Api.deleteMessage({ chat_id: CID, message_id: request.message_id }); } catch (e) {} }   // keep the secret out of the chat
    done("✅ <b>" + esc(st.label) + "</b> " + (val === "" ? "cleared." : "updated to <code>" + esc((st.key === "gw_api_key" || st.key === "rs_key") && val ? "••••" + val.slice(-4) : val) + "</code>"), [[B("Back", st.back || "/admin", "primary", "5240177683886784793")]]);
    return;
  }

  if (st.t === "coadmin") {
    var cid2 = txt.replace(/\D/g, "");
    if (!cid2) { sendTo(CID, "⚠️ Send a numeric Telegram ID."); return; }
    Bot.setProperty("co_admin_" + cid2, st.op === "add" ? "1" : "", "string");
    done("✅ <code>" + cid2 + "</code> " + (st.op === "add" ? "is now a co-admin." : "removed from co-admins."));
    return;
  }

  clearState();
  showMenu(u, false);
} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}
