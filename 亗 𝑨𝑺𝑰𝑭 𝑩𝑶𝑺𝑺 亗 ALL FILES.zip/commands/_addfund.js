/**#command
name: /addfund
answer:
keyboard:
parse_mode: markdown
aliases:
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// ================= SHARED HELPERS (auto-included in every command) =================
function CFG(k, d) { var v = Bot.getProperty(k); return (v === null || typeof v === "undefined" || v === "") ? d : v; }
function num(v, d) { var n = Number(v); return isFinite(n) ? n : d; }
function r2(n) { return Math.round(num(n, 0) * 100) / 100; }
function esc(s) { return String(s === null || typeof s === "undefined" ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
function money(n) { return "₹" + r2(n).toFixed(2); }
function fmtDate(t) { if (!t) return "-"; return new Date(Number(t) + 19800000).toISOString().slice(0, 16).replace("T", " "); }

var OWNER = String(CFG("owner_id", "2049656553"));
var UID = String(user.telegramid);
var CID = chat.chatid;
var IS_NEW = false;

function isAdmin(id) { id = String(typeof id === "undefined" ? UID : id); return id === OWNER || !!Bot.getProperty("co_admin_" + id); }
function displayName() { var n = String((user.first_name || "") + " " + (user.last_name || "")).trim(); return n || user.username || "User"; }

// ---------- users ----------
function newUser(id) {
  return { id: String(id), name: displayName(), username: user.username || "", joined: Date.now(), bal: 0, spent: 0,
    order_count: 0, orders: [], topups: [], ref_by: null, ref_paid: false, refs: 0, ref_earn: 0, last_daily: 0, daily_total: 0 };
}
function loadUser(id) { var u = Bot.getProperty("u_" + id); return (u && typeof u === "object") ? u : null; }
function saveUser(u) { Bot.setProperty("u_" + u.id, u, "json"); }
function ensureUser() {
  var u = loadUser(UID);
  if (!u) {
    u = newUser(UID); IS_NEW = true;
    var list = Bot.getProperty("users");
    if (!Array.isArray(list)) list = [];
    list.push(UID);
    Bot.setProperty("users", list, "json");
  } else {
    u.name = displayName(); u.username = user.username || "";
  }
  saveUser(u);
  return u;
}

// ---------- conversation state ----------
function getState() { var s = User.getProperty("st"); return (s && typeof s === "object") ? s : null; }
function setState(o) { User.setProperty("st", o, "json"); }
function clearState() { User.setProperty("st", "", "string"); }

// ---------- products ----------
function products() { var p = Bot.getProperty("products"); return Array.isArray(p) ? p : []; }
function saveProducts(p) { Bot.setProperty("products", p, "json"); }
function stockOf(prod) { var n = 0; if (prod && prod.plans) for (var i = 0; i < prod.plans.length; i++) n += (prod.plans[i].keys || []).length; return n; }
function discPct() { return 0; }
function finalPrice(price, u) { return r2(num(price, 0)); }
function inc(k, by) { Bot.setProperty(k, String(r2(num(Bot.getProperty(k), 0) + by)), "string"); }

function linkOf(v) {
  v = String(v || "").trim(); if (!v) return "";
  if (/^https?:\/\//i.test(v)) return v;
  if (/^t\.me\//i.test(v)) return "https://" + v;
  return "https://t.me/" + v.replace(/^@/, "");
}

// ---------- telegram helpers ----------
function B(text, data, style, icon) { var b = { text: text, callback_data: data }; if (style) b.style = style; if (icon) b.icon_custom_emoji_id = String(icon); return b; }
function Ub(text, url, style) { var b = { text: text, url: url }; if (style) b.style = style; return b; }
function qid() { if (!request) return null; return request.id || (request.callback_query && request.callback_query.id) || null; }
function isCb() { return !!(request && request.message && request.message.message_id && qid()); }
function ack(text, alert) {
  var q = qid(); if (!q) return;
  try { var o = { callback_query_id: String(q) }; if (text) { o.text = text; o.show_alert = !!alert; } Api.answerCallbackQuery(o); } catch (e) {}
}
function fail(text) { if (qid()) ack(text, true); else Api.sendMessage({ chat_id: CID, text: text }); }
function sendTo(id, text, rows) {
  var o = { chat_id: id, text: text, parse_mode: "HTML", disable_web_page_preview: true };
  if (rows) o.reply_markup = JSON.stringify({ inline_keyboard: rows });
  try { Api.sendMessage(o); } catch (e) {}
}
// Edit the tapped message (or send a new one when called from plain text / a photo message)
function show(text, rows) {
  var markup = JSON.stringify({ inline_keyboard: rows || [] });
  ack();
  if (isCb()) {
    var m = request.message;
    if (m.photo || m.video || m.document) {
      try { Api.deleteMessage({ chat_id: CID, message_id: m.message_id }); } catch (e) {}
      Api.sendMessage({ chat_id: CID, text: text, parse_mode: "HTML", disable_web_page_preview: true, reply_markup: markup });
    } else {
      Api.editMessageText({ chat_id: CID, message_id: m.message_id, text: text, parse_mode: "HTML", disable_web_page_preview: true, reply_markup: markup });
    }
  } else {
    Api.sendMessage({ chat_id: CID, text: text, parse_mode: "HTML", disable_web_page_preview: true, reply_markup: markup });
  }
}
var BACK = [B("Back", "/back", "primary", "5240177683886784793")];
// ---------- global Maintenance Mode (bot off for all users; admins bypass) ----------
if (CFG("maint_mode", "") === "1" && !isAdmin()) {
  try {
    var mmLink = linkOf(CFG("update_link", ""));
    show("🛠 <b>Bot Under Maintenance</b>\n\nThe bot is currently under maintenance. Please check back later — sorry for the inconvenience!",
      mmLink ? [[{ text: "Check Update", url: mmLink, style: "primary" }]] : []);
  } catch (e) {}
  return;
}



// ---------- add-balance look & feel (shared by /addfund, /kp and the typed-amount handler) ----------
var MAXT = 50000;
var ICON_BAG = "6210859306602995217";   // money-bag premium emoji
var ICON_BACK = "5240177683886784793";  // back-arrow premium emoji
var RULE = "━━━━━━━━━━━━━━━━━━━━━━";
function fmtInt(n) { return String(Math.floor(num(n, 0))).replace(/\B(?=(\d{3})+(?!\d))/g, ","); }
function bagEmoji() { return "<tg-emoji emoji-id=\"" + ICON_BAG + "\">💰</tg-emoji>"; }
var GEN_TEXT = "<blockquote><tg-emoji emoji-id=\"6219547832169273793\">💳</tg-emoji> <b>ɢᴇɴᴇʀᴀᴛɪɴɢ ꜱᴇᴄᴜʀᴇ ǫʀ</b></blockquote>\n\n" +
  "<blockquote><tg-emoji emoji-id=\"6159057628736528371\">⏳</tg-emoji> ᴄʀᴇᴀᴛɪɴɢ ʏᴏᴜʀ ᴘᴀʏᴍᴇɴᴛ ᴏʀᴅᴇʀ...\n<tg-emoji emoji-id=\"5449913031578379785\">🛡️</tg-emoji> ᴘʟᴇᴀꜱᴇ ᴡᴀɪᴛ ᴀ ꜰᴇᴡ ꜱᴇᴄᴏɴᴅꜱ</blockquote>";
function msgIdOf(res) {
  try {
    if (!res) return null;
    if (res.message_id) return res.message_id;
    if (res.result && res.result.message_id) return res.result.message_id;
  } catch (e) {}
  return null;
}
// Shows "GENERATING SECURE QR", sends the UPI QR, then removes the "generating" notice.
// mid = message id to turn into the notice (keypad / menu message); null = send a fresh notice.
// ---------- AUTO PAYMENT GATEWAY (galumodz.site) ----------
// All gateway settings come from the admin payment panel (Bot properties):
//   gw_create_url  -> create order endpoint      gw_verify_url -> order status endpoint
//   gw_api_key     -> API key                    upi_name / store_name -> shown on QR
var GW_EXPIRY_MS = 5 * 60 * 1000;   // QR valid for 5 minutes

// ADAPT ONLY THIS FUNCTION to the HTTP helper your TeleBotHost build provides.
// It must POST JSON to url and return the parsed JSON object from the gateway.
// Gateway: galumodzgateway.site (one api.php, action = create_order | verify). Built-in default; admin can override.
var GW_API_DEFAULT = "https://galumodzgateway.site/api.php";
var GW_CREATE_DEFAULT = GW_API_DEFAULT;
var GW_VERIFY_DEFAULT = GW_API_DEFAULT;
var GW_EXPIRY_MS = 5 * 60 * 1000;   // checkout valid 5 minutes
function gwHeaders() { return { "Content-Type": "application/json" }; }
function gwParse(c) { if (c && typeof c === "object") return c; try { return JSON.parse(String(c || "")); } catch (e) { return null; } }
function gwNote(where, st, c) { try { Bot.setProperty("gw_last_error", where + " HTTP " + String(st) + ": " + String(c || "").slice(0, 300), "string"); } catch (e) {} }
// error shown on the "generating" message (or a fresh message); admin also sees the real reason
function gwErr(mid, reason) {
  var t = "⚠️ <b>Could not create payment.</b>\nPlease try again in a moment." + (isAdmin() && reason ? "\n\n<i>Admin debug:</i> <code>" + esc(reason) + "</code>" : "");
  var rows = JSON.stringify({ inline_keyboard: [[B("Back", "/back", "primary", ICON_BACK)]] });
  if (mid) { try { Api.editMessageText({ chat_id: CID, message_id: mid, text: t, parse_mode: "HTML", reply_markup: rows }); return; } catch (e) {} }
  Api.sendMessage({ chat_id: CID, text: t, parse_mode: "HTML", reply_markup: rows });
}
function gwOrderSave(oid, o) { Bot.setProperty("gw_order_" + oid, o, "json"); }
function gwOrderLoad(oid) { var o = Bot.getProperty("gw_order_" + oid); return (o && typeof o === "object") ? o : null; }
function gwKb(oid) {
  return [
    [B("✅ I have paid", "/adpay paid " + oid, "success")],
    [B("❌ Cancel Payment", "/adpay cancel " + oid, "danger")]
  ];
}

// Add Balance: create gateway order -> send QR (5 min) with "I have paid" / "Cancel Payment"
// Add Balance: FamGateway create-order -> QR (5 min) with "I have paid" / "Cancel Payment"
// Add Balance: async HTTP to FamGateway. Result comes back in /adpay created (or cerr).
function createOrder(amt, mid) {
  var empty = JSON.stringify({ inline_keyboard: [] });
  if (mid) { try { Api.editMessageText({ chat_id: CID, message_id: mid, text: GEN_TEXT, parse_mode: "HTML", reply_markup: empty }); } catch (e) {} }
  else { try { mid = msgIdOf(Api.sendMessage({ chat_id: CID, text: GEN_TEXT, parse_mode: "HTML" })); } catch (e) {} }
  clearState();
  if (!CFG("gw_api_key", "")) { gwErr(mid, "API key not set (Admin > Payment Settings)"); return; }
  // our own unique reference per attempt: letters/digits only, max 40
  var ourId = "BAL" + UID + "T" + Date.now();
  User.setProperty("gw_pend", { amt: num(amt, 0), mid: mid || null, ourId: ourId }, "json");
  try {
    HTTP.post({
      url: CFG("gw_create_url", GW_CREATE_DEFAULT),
      headers: gwHeaders(),
      body: { action: "create_order", api_key: CFG("gw_api_key", ""), amount: num(amt, 0).toFixed(2), order_id: ourId, expiry_minutes: 5 },
      success: "/adpay created",
      error: "/adpay cerr"
    });
  } catch (e) {
    gwNote("create", "send", e.message);
    gwErr(mid, String(e.message));
  }
}

try {
  var u = ensureUser();
  clearState();
  if (!CFG("gw_api_key", "")) {
    show("💳 <b>Add Balance</b>\n\n⚠️ Payments are not set up yet.\nPlease contact support.", [[B("📞 Support", "/support", "danger")], BACK]);
    return;
  }
  setState({ t: "dep_amount", kp: "" }); // typing an amount in chat also works
  var q = function (n) { return B("₹" + n, "/kp q " + n, "success", ICON_BAG); };
  show(bagEmoji() + " <b>ADD FUNDS TO WALLET</b>\n\n" +
    "Choose a quick amount to add or type/use a custom one below.\n\n" +
    "<blockquote>Predefined amounts are faster to process!</blockquote>",
    [
      [q(100), q(200)],
      [q(500), q(1000)],
      [B("TYPE CUSTOM AMOUNT", "/kp custom", "success", "5240177683886784793")],
      [B("Back to Menu", "/back", "danger", ICON_BACK)]
    ]);
} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}
