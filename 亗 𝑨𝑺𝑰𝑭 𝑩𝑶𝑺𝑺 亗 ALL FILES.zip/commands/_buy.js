/**#command
name: /buy
answer:
keyboard:
parse_mode: markdown
aliases:
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// ================= SHARED HELPERS (auto-included in every command) =================
function CFG(k, d) { var v = Bot.getProperty(k); return (v === null || typeof v === "undefined" || v === "") ? d : v; }
function num(v, d) { var n = Number(v); return isFinite(n) ? n : d; }
function r2(n) { return Math.round(num(n, 0) * 100) / 100; }
function esc(s) { return String(s === null || typeof s === "undefined" ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
function money(n) { return "₹" + r2(n).toFixed(2); }
function fmtDate(t) { if (!t) return "-"; return new Date(Number(t) + 19800000).toISOString().slice(0, 16).replace("T", " "); }

var OWNER = String(CFG("owner_id", "2049656553"));
var UID = String(user.telegramid);
var CID = chat.chatid;
var IS_NEW = false;

function isAdmin(id) { id = String(typeof id === "undefined" ? UID : id); return id === OWNER || !!Bot.getProperty("co_admin_" + id); }
function displayName() { var n = String((user.first_name || "") + " " + (user.last_name || "")).trim(); return n || user.username || "User"; }

// ---------- users ----------
function newUser(id) {
  return { id: String(id), name: displayName(), username: user.username || "", joined: Date.now(), bal: 0, spent: 0,
    order_count: 0, orders: [], topups: [], ref_by: null, ref_paid: false, refs: 0, ref_earn: 0, last_daily: 0, daily_total: 0 };
}
function loadUser(id) { var u = Bot.getProperty("u_" + id); return (u && typeof u === "object") ? u : null; }
function saveUser(u) { Bot.setProperty("u_" + u.id, u, "json"); }
function ensureUser() {
  var u = loadUser(UID);
  if (!u) {
    u = newUser(UID); IS_NEW = true;
    var list = Bot.getProperty("users");
    if (!Array.isArray(list)) list = [];
    list.push(UID);
    Bot.setProperty("users", list, "json");
  } else {
    u.name = displayName(); u.username = user.username || "";
  }
  saveUser(u);
  return u;
}

// ---------- conversation state ----------
function getState() { var s = User.getProperty("st"); return (s && typeof s === "object") ? s : null; }
function setState(o) { User.setProperty("st", o, "json"); }
function clearState() { User.setProperty("st", "", "string"); }

// ---------- products ----------
function products() { var p = Bot.getProperty("products"); return Array.isArray(p) ? p : []; }
function saveProducts(p) { Bot.setProperty("products", p, "json"); }
function stockOf(prod) { var n = 0; if (prod && prod.plans) for (var i = 0; i < prod.plans.length; i++) n += (prod.plans[i].keys || []).length; return n; }
function discPct() { return 0; }
// admin-set price is charged as-is (no automatic repeat discount)
function finalPrice(price, u) { return r2(num(price, 0)); }
function inc(k, by) { Bot.setProperty(k, String(r2(num(Bot.getProperty(k), 0) + by)), "string"); }

function linkOf(v) {
  v = String(v || "").trim(); if (!v) return "";
  if (/^https?:\/\//i.test(v)) return v;
  if (/^t\.me\//i.test(v)) return "https://" + v;
  return "https://t.me/" + v.replace(/^@/, "");
}

// ---------- telegram helpers ----------
function B(text, data, style, icon) { var b = { text: text, callback_data: data }; if (style) b.style = style; if (icon) b.icon_custom_emoji_id = String(icon); return b; }
function Ub(text, url, style) { var b = { text: text, url: url }; if (style) b.style = style; return b; }
function qid() { if (!request) return null; return request.id || (request.callback_query && request.callback_query.id) || null; }
function isCb() { return !!(request && request.message && request.message.message_id && qid()); }
function ack(text, alert) {
  var q = qid(); if (!q) return;
  try { var o = { callback_query_id: String(q) }; if (text) { o.text = text; o.show_alert = !!alert; } Api.answerCallbackQuery(o); } catch (e) {}
}
function fail(text) { if (qid()) ack(text, true); else Api.sendMessage({ chat_id: CID, text: text }); }
function sendTo(id, text, rows) {
  var o = { chat_id: id, text: text, parse_mode: "HTML", disable_web_page_preview: true };
  if (rows) o.reply_markup = JSON.stringify({ inline_keyboard: rows });
  try { Api.sendMessage(o); } catch (e) {}
}
// Edit the tapped message (or send a new one when called from plain text / a photo message)
function show(text, rows) {
  var markup = JSON.stringify({ inline_keyboard: rows || [] });
  ack();
  if (isCb()) {
    var m = request.message;
    if (m.photo || m.video || m.document) {
      try { Api.deleteMessage({ chat_id: CID, message_id: m.message_id }); } catch (e) {}
      Api.sendMessage({ chat_id: CID, text: text, parse_mode: "HTML", disable_web_page_preview: true, reply_markup: markup });
    } else {
      Api.editMessageText({ chat_id: CID, message_id: m.message_id, text: text, parse_mode: "HTML", disable_web_page_preview: true, reply_markup: markup });
    }
  } else {
    Api.sendMessage({ chat_id: CID, text: text, parse_mode: "HTML", disable_web_page_preview: true, reply_markup: markup });
  }
}
var BACK = [B("Back", "/back", "primary", "5240177683886784793")];
// ---------- global Maintenance Mode (bot off for all users; admins bypass) ----------
if (CFG("maint_mode", "") === "1" && !isAdmin()) {
  try {
    var mmLink = linkOf(CFG("update_link", ""));
    show("🛠 <b>Bot Under Maintenance</b>\n\nThe bot is currently under maintenance. Please check back later — sorry for the inconvenience!",
      mmLink ? [[{ text: "Check Update", url: mmLink, style: "primary" }]] : []);
  } catch (e) {}
  return;
}

// ---------- device types (premium icon ids: put the custom emoji id in "icon", else the plain emoji in "fb" is used) ----------
var DEVICES = loadDevices();
function loadDevices() {
  var d = Bot.getProperty("devices");
  if (Array.isArray(d)) return d;
  return [
  { k: "anr", label: "ANDROID NONROOT", icon: "6231107122466131612", fb: "🤖" },
  { k: "ar",  label: "ANDROID ROOT",    icon: "6231107122466131612", fb: "🤖" },
  { k: "pc",  label: "PC / COMPUTER",   icon: "5440784572511972384", fb: "💻" },
  { k: "ios", label: "IOS / IPHONE",    icon: "5929172914422156484", fb: "🍎" }
];
}
function saveDevices(arr) { Bot.setProperty("devices", arr, "json"); DEVICES = arr; }
function devOf(k) { for (var d = 0; d < DEVICES.length; d++) if (DEVICES[d].k === k) return DEVICES[d]; return null; }
function devBtn(d, data) { return B(d.icon ? d.label : d.fb + " " + d.label, data, "primary", d.icon); }

var BACK_RED = [B("Back", "/back", "danger", "5240177683886784793")];

// ---------- maintenance / stock-out helpers ----------
// ---------- Reseller API helpers ----------
var RS_DEFAULT = "https://galumodz.shop/api/reseller_v1.php";
function rsUrl() { return CFG("rs_url", RS_DEFAULT); }
function rsOn() { return !!CFG("rs_key", ""); }
// ADAPT ONLY THIS FUNCTION if your TeleBotHost build sends HTTP.post bodies differently.
// The Reseller API expects a normal form POST (api_key, action, product_id, duration, quantity).
function rsPost(fields, okCmd, errCmd) {
  var parts = [];
  for (var fk in fields) if (fields[fk] !== "" && fields[fk] !== null && typeof fields[fk] !== "undefined") parts.push(encodeURIComponent(fk) + "=" + encodeURIComponent(String(fields[fk])));
  HTTP.post({ url: rsUrl(), headers: { "Content-Type": "application/x-www-form-urlencoded", "X-API-Key": CFG("rs_key", "") }, body: parts.join("&"), success: okCmd, error: errCmd });
}
function planOut(pl) { if (!pl || pl.out) return true; if ((pl.keys || []).length) return false; return !(pl.pid && rsOn()); }
function prodAvail(p) { if (!p || p.maint || !p.plans) return false; for (var q = 0; q < p.plans.length; q++) if (!planOut(p.plans[q])) return true; return false; }

try {
  ensureUser(); clearState();
  var dk = String(params || "").trim();
  var dv = devOf(dk);
  if (!dv) {
    // step 1: choose device type
    var drows = [];
    for (var d = 0; d < DEVICES.length; d++) drows.push([devBtn(DEVICES[d], "/buy " + DEVICES[d].k)]);
    drows.push(BACK_RED);
    show("<blockquote><tg-emoji emoji-id=\"5451937962629544243\">🛍</tg-emoji> <b>PRODUCT STORE — SHOP</b> <tg-emoji emoji-id=\"5451937962629544243\">🛍</tg-emoji></blockquote>\n<tg-emoji emoji-id=\"5192657890845935166\">📱</tg-emoji> Select your device type:", drows);
    return;
  }
  // step 2: products for the chosen device (products with no device set show under every device)
  var ps = products();
  var rows = [], row = [], shown = 0;
  for (var i = 0; i < ps.length; i++) {
    if (ps[i].dev && ps[i].dev !== dv.k) continue;
    shown++;
    var st = prodAvail(ps[i]) ? 1 : 0;
    var ic = ps[i].icon ? String(ps[i].icon) : "";
    row.push(B(ic ? ps[i].name : "🛒 " + ps[i].name, "/prod " + i, st ? "success" : "danger", ic));
    if (row.length === 2) { rows.push(row); row = []; }
  }
  if (row.length) rows.push(row);
  rows.push([B("Back", "/buy", "primary", "5240177683886784793")]);
  show("<blockquote><tg-emoji emoji-id=\"5451937962629544243\">🛍</tg-emoji> <b>PRODUCT STORE — " + dv.label + "</b> <tg-emoji emoji-id=\"5451937962629544243\">🛍</tg-emoji></blockquote>\n" + (shown
    ? "<tg-emoji emoji-id=\"6093562529978522804\">🛒</tg-emoji> Select a product:"
    : "📦 <b>No products available for this device yet.</b>\n\nPlease check back soon!"), rows);
} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}
