/**#command
name: /back
answer:
keyboard:
parse_mode: markdown
aliases:
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// ================= SHARED HELPERS (auto-included in every command) =================
function CFG(k, d) { var v = Bot.getProperty(k); return (v === null || typeof v === "undefined" || v === "") ? d : v; }
function num(v, d) { var n = Number(v); return isFinite(n) ? n : d; }
function r2(n) { return Math.round(num(n, 0) * 100) / 100; }
function esc(s) { return String(s === null || typeof s === "undefined" ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
function money(n) { return "₹" + r2(n).toFixed(2); }
function fmtDate(t) { if (!t) return "-"; return new Date(Number(t) + 19800000).toISOString().slice(0, 16).replace("T", " "); }

var OWNER = String(CFG("owner_id", "2049656553"));
var UID = String(user.telegramid);
var CID = chat.chatid;
var IS_NEW = false;

function isAdmin(id) { id = String(typeof id === "undefined" ? UID : id); return id === OWNER || !!Bot.getProperty("co_admin_" + id); }
function displayName() { var n = String((user.first_name || "") + " " + (user.last_name || "")).trim(); return n || user.username || "User"; }

// ---------- users ----------
function newUser(id) {
  return { id: String(id), name: displayName(), username: user.username || "", joined: Date.now(), bal: 0, spent: 0,
    order_count: 0, orders: [], topups: [], ref_by: null, ref_paid: false, refs: 0, ref_earn: 0, last_daily: 0, daily_total: 0 };
}
function loadUser(id) { var u = Bot.getProperty("u_" + id); return (u && typeof u === "object") ? u : null; }
function saveUser(u) { Bot.setProperty("u_" + u.id, u, "json"); }
function ensureUser() {
  var u = loadUser(UID);
  if (!u) {
    u = newUser(UID); IS_NEW = true;
    var list = Bot.getProperty("users");
    if (!Array.isArray(list)) list = [];
    list.push(UID);
    Bot.setProperty("users", list, "json");
  } else {
    u.name = displayName(); u.username = user.username || "";
  }
  saveUser(u);
  return u;
}

// ---------- conversation state ----------
function getState() { var s = User.getProperty("st"); return (s && typeof s === "object") ? s : null; }
function setState(o) { User.setProperty("st", o, "json"); }
function clearState() { User.setProperty("st", "", "string"); }

// ---------- products ----------
function products() { var p = Bot.getProperty("products"); return Array.isArray(p) ? p : []; }
function saveProducts(p) { Bot.setProperty("products", p, "json"); }
function stockOf(prod) { var n = 0; if (prod && prod.plans) for (var i = 0; i < prod.plans.length; i++) n += (prod.plans[i].keys || []).length; return n; }
function discPct() { return 0; }
function finalPrice(price, u) { return r2(num(price, 0)); }
function inc(k, by) { Bot.setProperty(k, String(r2(num(Bot.getProperty(k), 0) + by)), "string"); }

function linkOf(v) {
  v = String(v || "").trim(); if (!v) return "";
  if (/^https?:\/\//i.test(v)) return v;
  if (/^t\.me\//i.test(v)) return "https://" + v;
  return "https://t.me/" + v.replace(/^@/, "");
}

// ---------- telegram helpers ----------
function B(text, data, style, icon) { var b = { text: text, callback_data: data }; if (style) b.style = style; if (icon) b.icon_custom_emoji_id = String(icon); return b; }
function Ub(text, url, style, icon) { var b = { text: text, url: url }; if (style) b.style = style; if (icon) b.icon_custom_emoji_id = String(icon); return b; }
function qid() { if (!request) return null; return request.id || (request.callback_query && request.callback_query.id) || null; }
function isCb() { return !!(request && request.message && request.message.message_id && qid()); }
function ack(text, alert) {
  var q = qid(); if (!q) return;
  try { var o = { callback_query_id: String(q) }; if (text) { o.text = text; o.show_alert = !!alert; } Api.answerCallbackQuery(o); } catch (e) {}
}
function fail(text) { if (qid()) ack(text, true); else Api.sendMessage({ chat_id: CID, text: text }); }
function sendTo(id, text, rows) {
  var o = { chat_id: id, text: text, parse_mode: "HTML", disable_web_page_preview: true };
  if (rows) o.reply_markup = JSON.stringify({ inline_keyboard: rows });
  try { Api.sendMessage(o); } catch (e) {}
}
// Edit the tapped message (or send a new one when called from plain text / a photo message)
function show(text, rows) {
  var markup = JSON.stringify({ inline_keyboard: rows || [] });
  ack();
  if (isCb()) {
    var m = request.message;
    if (m.photo || m.video || m.document) {
      try { Api.deleteMessage({ chat_id: CID, message_id: m.message_id }); } catch (e) {}
      Api.sendMessage({ chat_id: CID, text: text, parse_mode: "HTML", disable_web_page_preview: true, reply_markup: markup });
    } else {
      Api.editMessageText({ chat_id: CID, message_id: m.message_id, text: text, parse_mode: "HTML", disable_web_page_preview: true, reply_markup: markup });
    }
  } else {
    Api.sendMessage({ chat_id: CID, text: text, parse_mode: "HTML", disable_web_page_preview: true, reply_markup: markup });
  }
}
var BACK = [B("Back", "/back", "primary", "5240177683886784793")];
// ---------- global Maintenance Mode (bot off for all users; admins bypass) ----------
if (CFG("maint_mode", "") === "1" && !isAdmin()) {
  try {
    var mmLink = linkOf(CFG("update_link", ""));
    show("🛠 <b>Bot Under Maintenance</b>\n\nThe bot is currently under maintenance. Please check back later — sorry for the inconvenience!",
      mmLink ? [[{ text: "Check Update", url: mmLink, style: "primary" }]] : []);
  } catch (e) {}
  return;
}

// ================= MAIN MENU (same layout as the reference screenshot) =================
function menuText(u, isNew) {
  var store = esc(CFG("store_name", "亗 𝑨𝑺𝑰𝑭 𝑩𝑶𝑺𝑺 亗 𝗦𝗛𝗢𝗣"));
  var LINE = "────────────────────────";
  var PAD = new Array(29).join("\u2800"); // invisible filler: pins the bubble to one fixed width (change 29 to make wider/narrower)
  return "<tg-emoji emoji-id=\"6093562529978522804\">🛒</tg-emoji> ─── <b>" + store + "</b> ─── <tg-emoji emoji-id=\"6093562529978522804\">🛒</tg-emoji>\n\n" +
    "<tg-emoji emoji-id=\"6057728771719435723\">👑</tg-emoji> <i>Welcome,</i> <b><i>" + esc(u.name) + "</i></b>\n\n" +
    "<tg-emoji emoji-id=\"6208671660715809463\">🔼</tg-emoji> ─── <b>STORE HIGHLIGHTS</b> ─── <tg-emoji emoji-id=\"6208671660715809463\">🔼</tg-emoji>\n\n" +
    "<blockquote>" +
    "<tg-emoji emoji-id=\"5472057595193743789\">🎮</tg-emoji> Premium Game Keys\n" +
    "<tg-emoji emoji-id=\"5368554037320900698\">🟢</tg-emoji> Instant Delivery 24/7\n" +
    "<tg-emoji emoji-id=\"6165821484968188344\">1️⃣</tg-emoji> 100% Secure Payment\n" +
    "<tg-emoji emoji-id=\"6093377734715642495\">🏷</tg-emoji> Best Prices Guaranteed\n" +
    "<tg-emoji emoji-id=\"5447419223242449630\">🇮🇳</tg-emoji> Safe And Trusted\n" +
    "<tg-emoji emoji-id=\"5235570365094188078\">✅</tg-emoji> Professional Support" +
    "</blockquote>\n\n" +
    LINE + "\n" +
    "<tg-emoji emoji-id=\"6210859306602995217\">💰</tg-emoji> <b>Wallet Balance:</b> " + money(u.bal) + "\n" +
    LINE + "\n" + PAD + "\n" +
    "<tg-emoji emoji-id=\"5231102735817918643\">🔥</tg-emoji> <i>Tap Shop Now to Start!</i>";
}
// How To Use Bot: direct link button (opens the video/link straight away); falls back to /howto text if no link is set
function howtoBtn() {
  var l = linkOf(CFG("howto_link", ""));
  var ic = "5427158904729513162";
  var hb = CFG("howto_btn", "How To Use");
  return l ? Ub(hb, l, "primary", ic) : B(hb, "/howto", "primary", ic);
}
function menuKb() {
  return [
    [B("Shop Now", "/buy", "danger", "6093562529978522804")],
    [B(CFG("update_btn", "Check Update"), "/update", "success", "5255741073409452371"), B("Add Balance", "/addfund", "primary", "6210859306602995217")],
    [B("My Profile", "/profile", "success", "5258362837411045098")],
    [B("Refer And Earn", "/refer", "success", "5260450573768990626"), howtoBtn()],
    [B("Support", "/support", "danger", "5253742260054409879"), B("Daily Gift", "/daily", "success", "5442939099906325301")]
  ];
}
function showMenu(u, isNew) { show(menuText(u, isNew), menuKb()); }

try {
  var u = ensureUser();
  clearState();
  showMenu(u, false);
} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}
