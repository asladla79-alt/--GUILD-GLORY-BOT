/**#command
name: /adpay
answer:
keyboard:
parse_mode: markdown
aliases:
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// ================= SHARED HELPERS (auto-included in every command) =================
function CFG(k, d) { var v = Bot.getProperty(k); return (v === null || typeof v === "undefined" || v === "") ? d : v; }
function num(v, d) { var n = Number(v); return isFinite(n) ? n : d; }
function r2(n) { return Math.round(num(n, 0) * 100) / 100; }
function esc(s) { return String(s === null || typeof s === "undefined" ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
function money(n) { return "₹" + r2(n).toFixed(2); }
function fmtDate(t) { if (!t) return "-"; return new Date(Number(t) + 19800000).toISOString().slice(0, 16).replace("T", " "); }

var OWNER = String(CFG("owner_id", "2049656553"));
var UID = String(user.telegramid);
var CID = chat.chatid;
var IS_NEW = false;

function isAdmin(id) { id = String(typeof id === "undefined" ? UID : id); return id === OWNER || !!Bot.getProperty("co_admin_" + id); }
function displayName() { var n = String((user.first_name || "") + " " + (user.last_name || "")).trim(); return n || user.username || "User"; }

// ---------- users ----------
function newUser(id) {
  return { id: String(id), name: displayName(), username: user.username || "", joined: Date.now(), bal: 0, spent: 0,
    order_count: 0, orders: [], topups: [], ref_by: null, ref_paid: false, refs: 0, ref_earn: 0, last_daily: 0, daily_total: 0 };
}
function loadUser(id) { var u = Bot.getProperty("u_" + id); return (u && typeof u === "object") ? u : null; }
function saveUser(u) { Bot.setProperty("u_" + u.id, u, "json"); }
function ensureUser() {
  var u = loadUser(UID);
  if (!u) {
    u = newUser(UID); IS_NEW = true;
    var list = Bot.getProperty("users");
    if (!Array.isArray(list)) list = [];
    list.push(UID);
    Bot.setProperty("users", list, "json");
  } else {
    u.name = displayName(); u.username = user.username || "";
  }
  saveUser(u);
  return u;
}

// ---------- conversation state ----------
function getState() { var s = User.getProperty("st"); return (s && typeof s === "object") ? s : null; }
function setState(o) { User.setProperty("st", o, "json"); }
function clearState() { User.setProperty("st", "", "string"); }

// ---------- products ----------
function products() { var p = Bot.getProperty("products"); return Array.isArray(p) ? p : []; }
function saveProducts(p) { Bot.setProperty("products", p, "json"); }
function stockOf(prod) { var n = 0; if (prod && prod.plans) for (var i = 0; i < prod.plans.length; i++) n += (prod.plans[i].keys || []).length; return n; }
function discPct() { return 0; }
function finalPrice(price, u) { return r2(num(price, 0)); }
function inc(k, by) { Bot.setProperty(k, String(r2(num(Bot.getProperty(k), 0) + by)), "string"); }

function linkOf(v) {
  v = String(v || "").trim(); if (!v) return "";
  if (/^https?:\/\//i.test(v)) return v;
  if (/^t\.me\//i.test(v)) return "https://" + v;
  return "https://t.me/" + v.replace(/^@/, "");
}

// ---------- telegram helpers ----------
function B(text, data, style, icon) { var b = { text: text, callback_data: data }; if (style) b.style = style; if (icon) b.icon_custom_emoji_id = String(icon); return b; }
function Ub(text, url, style) { var b = { text: text, url: url }; if (style) b.style = style; return b; }
function qid() { if (!request) return null; return request.id || (request.callback_query && request.callback_query.id) || null; }
function isCb() { return !!(request && request.message && request.message.message_id && qid()); }
function ack(text, alert) {
  var q = qid(); if (!q) return;
  try { var o = { callback_query_id: String(q) }; if (text) { o.text = text; o.show_alert = !!alert; } Api.answerCallbackQuery(o); } catch (e) {}
}
function fail(text) { if (qid()) ack(text, true); else Api.sendMessage({ chat_id: CID, text: text }); }
function sendTo(id, text, rows) {
  var o = { chat_id: id, text: text, parse_mode: "HTML", disable_web_page_preview: true };
  if (rows) o.reply_markup = JSON.stringify({ inline_keyboard: rows });
  try { Api.sendMessage(o); } catch (e) {}
}
// Edit the tapped message (or send a new one when called from plain text / a photo message)
function show(text, rows) {
  var markup = JSON.stringify({ inline_keyboard: rows || [] });
  ack();
  if (isCb()) {
    var m = request.message;
    if (m.photo || m.video || m.document) {
      try { Api.deleteMessage({ chat_id: CID, message_id: m.message_id }); } catch (e) {}
      Api.sendMessage({ chat_id: CID, text: text, parse_mode: "HTML", disable_web_page_preview: true, reply_markup: markup });
    } else {
      Api.editMessageText({ chat_id: CID, message_id: m.message_id, text: text, parse_mode: "HTML", disable_web_page_preview: true, reply_markup: markup });
    }
  } else {
    Api.sendMessage({ chat_id: CID, text: text, parse_mode: "HTML", disable_web_page_preview: true, reply_markup: markup });
  }
}
var BACK = [B("Back", "/back", "primary", "5240177683886784793")];
// ---------- global Maintenance Mode (bot off for all users; admins bypass) ----------
if (CFG("maint_mode", "") === "1" && !isAdmin() && !/^(created|cerr|vres|verr|page|pgerr)\b/.test(String(params || "").trim())) {
  try {
    var mmLink = linkOf(CFG("update_link", ""));
    show("🛠 <b>Bot Under Maintenance</b>\n\nThe bot is currently under maintenance. Please check back later — sorry for the inconvenience!",
      mmLink ? [[{ text: "Check Update", url: mmLink, style: "primary" }]] : []);
  } catch (e) {}
  return;
}



// ---------- add-balance look & feel (shared by /addfund, /kp and the typed-amount handler) ----------
var MAXT = 50000;
var ICON_BAG = "6210859306602995217";   // money-bag premium emoji
var ICON_BACK = "5240177683886784793";  // back-arrow premium emoji
var RULE = "━━━━━━━━━━━━━━━━━━━━━━";
function fmtInt(n) { return String(Math.floor(num(n, 0))).replace(/\B(?=(\d{3})+(?!\d))/g, ","); }
function bagEmoji() { return "<tg-emoji emoji-id=\"" + ICON_BAG + "\">💰</tg-emoji>"; }
var GEN_TEXT = "<blockquote><tg-emoji emoji-id=\"6219547832169273793\">💳</tg-emoji> <b>ɢᴇɴᴇʀᴀᴛɪɴɢ ꜱᴇᴄᴜʀᴇ ǫʀ</b></blockquote>\n\n" +
  "<blockquote><tg-emoji emoji-id=\"6159057628736528371\">⏳</tg-emoji> ᴄʀᴇᴀᴛɪɴɢ ʏᴏᴜʀ ᴘᴀʏᴍᴇɴᴛ ᴏʀᴅᴇʀ...\n<tg-emoji emoji-id=\"5449913031578379785\">🛡️</tg-emoji> ᴘʟᴇᴀꜱᴇ ᴡᴀɪᴛ ᴀ ꜰᴇᴡ ꜱᴇᴄᴏɴᴅꜱ</blockquote>";
function msgIdOf(res) {
  try {
    if (!res) return null;
    if (res.message_id) return res.message_id;
    if (res.result && res.result.message_id) return res.result.message_id;
  } catch (e) {}
  return null;
}
// Shows "GENERATING SECURE QR", sends the UPI QR, then removes the "generating" notice.
// mid = message id to turn into the notice (keypad / menu message); null = send a fresh notice.
// ---------- AUTO PAYMENT GATEWAY (galumodz.site) ----------
// All gateway settings come from the admin payment panel (Bot properties):
//   gw_create_url  -> create order endpoint      gw_verify_url -> order status endpoint
//   gw_api_key     -> API key                    upi_name / store_name -> shown on QR
var GW_EXPIRY_MS = 5 * 60 * 1000;   // QR valid for 5 minutes

// ADAPT ONLY THIS FUNCTION to the HTTP helper your TeleBotHost build provides.
// It must POST JSON to url and return the parsed JSON object from the gateway.
// Gateway: galumodzgateway.site (one api.php, action = create_order | verify). Built-in default; admin can override.
var GW_API_DEFAULT = "https://galumodzgateway.site/api.php";
var GW_CREATE_DEFAULT = GW_API_DEFAULT;
var GW_VERIFY_DEFAULT = GW_API_DEFAULT;
var GW_EXPIRY_MS = 5 * 60 * 1000;   // checkout valid 5 minutes
function gwHeaders() { return { "Content-Type": "application/json" }; }
function gwParse(c) { if (c && typeof c === "object") return c; try { return JSON.parse(String(c || "")); } catch (e) { return null; } }
function gwNote(where, st, c) { try { Bot.setProperty("gw_last_error", where + " HTTP " + String(st) + ": " + String(c || "").slice(0, 300), "string"); } catch (e) {} }
// error shown on the "generating" message (or a fresh message); admin also sees the real reason
function gwErr(mid, reason) {
  var t = "⚠️ <b>Could not create payment.</b>\nPlease try again in a moment." + (isAdmin() && reason ? "\n\n<i>Admin debug:</i> <code>" + esc(reason) + "</code>" : "");
  var rows = JSON.stringify({ inline_keyboard: [[B("Back", "/back", "primary", ICON_BACK)]] });
  if (mid) { try { Api.editMessageText({ chat_id: CID, message_id: mid, text: t, parse_mode: "HTML", reply_markup: rows }); return; } catch (e) {} }
  Api.sendMessage({ chat_id: CID, text: t, parse_mode: "HTML", reply_markup: rows });
}
function gwOrderSave(oid, o) { Bot.setProperty("gw_order_" + oid, o, "json"); }
function gwOrderLoad(oid) { var o = Bot.getProperty("gw_order_" + oid); return (o && typeof o === "object") ? o : null; }

// Add Balance: create gateway order -> send QR (5 min) with "I have paid" / "Cancel Payment"
// ---------- AUTO PAYMENT GATEWAY (galumodz.site) ----------
// All gateway settings come from the admin payment panel (Bot properties):
//   gw_create_url  -> create order endpoint      gw_verify_url -> order status endpoint
//   gw_api_key     -> API key                    upi_name / store_name -> shown on QR
var GW_EXPIRY_MS = 5 * 60 * 1000;   // QR valid for 5 minutes

// ADAPT ONLY THIS FUNCTION to the HTTP helper your TeleBotHost build provides.
// It must POST JSON to url and return the parsed JSON object from the gateway.
function gwOrderSave(oid, o) { Bot.setProperty("gw_order_" + oid, o, "json"); }
function gwOrderLoad(oid) { var o = Bot.getProperty("gw_order_" + oid); return (o && typeof o === "object") ? o : null; }


function gwKb(oid, checkout) {
  var rows = [];
  var cu = String(checkout || "");
  if (/^https?:\/\//i.test(cu)) rows.push([Ub("Open Payment Page", cu, "primary")]);
  rows.push([B("✅ I have paid", "/adpay paid " + oid, "success")]);
  rows.push([B("❌ Cancel Payment", "/adpay cancel " + oid, "danger")]);
  return rows;
}
// keyboard for retry / error screens: Open Payment Page (if link known) + I have paid
function gwRetryKb(oid, checkout) {
  var rows = [];
  var cu = String(checkout || "");
  if (/^https?:\/\//i.test(cu)) rows.push([Ub("Open Payment Page", cu, "primary")]);
  rows.push([B("✅ I have paid", "/adpay paid " + oid, "success")]);
  return rows;
}
// fallback helpers: if Telegram rejects the Open Payment Page link or a premium emoji, retry without them
function noUrlRows(rows) {
  var out = [];
  for (var i = 0; i < rows.length; i++) { var r = []; for (var j = 0; j < rows[i].length; j++) { if (!rows[i][j].url) r.push(rows[i][j]); } if (r.length) out.push(r); }
  return out;
}
function plainEmoji(t) { return String(t).replace(/<tg-emoji[^>]*>([\s\S]*?)<\/tg-emoji>/g, "$1"); }
function failed(res) { try { return !!(res && res.ok === false); } catch (e) { return false; } }
// premium emoji helper
function tgEmo(id, fallback) { return "<tg-emoji emoji-id=\"" + id + "\">" + fallback + "</tg-emoji>"; }
// safe readers: callback-only variables may not exist in every context
function gwHs() { try { return typeof http_status !== "undefined" ? http_status : "?"; } catch (e) { return "?"; } }
function gwCt() { try { return typeof content !== "undefined" ? content : ""; } catch (e) { return ""; } }
function gwSend(text, rows) {
  rows = rows || [];
  var res = null;
  try { res = Api.sendMessage({ chat_id: CID, text: text, parse_mode: "HTML", disable_web_page_preview: true, reply_markup: JSON.stringify({ inline_keyboard: rows }) }); }
  catch (e) { res = { ok: false }; }
  if (failed(res)) {
    // retry safe: normal emoji, no url buttons
    Api.sendMessage({ chat_id: CID, text: plainEmoji(text), parse_mode: "HTML", disable_web_page_preview: true, reply_markup: JSON.stringify({ inline_keyboard: noUrlRows(rows) }) });
  }
}
function gwSendQr(info, qrSrc) {
  var cap = bagEmoji() + " <b>Add Balance — " + money(info.amt) + "</b>\n\n" +
    "Scan this QR and pay <b>" + money(info.amt) + "</b>.\n\n" +
    "Your balance updates <b>automatically</b> the moment payment is confirmed — no button tap needed.\n\n" +
    "⏰ This QR expires in <b>5 minutes</b> if payment isn't completed.";
  var sent = null;
  try { sent = Api.sendPhoto({ chat_id: CID, photo: qrSrc, parse_mode: "HTML", caption: cap, reply_markup: JSON.stringify({ inline_keyboard: gwKb(info.gid, info.checkout) }) }); }
  catch (e) { sent = { ok: false, err: e.message }; }
  if (failed(sent)) {
    // Telegram may reject the payment link button: retry without it
    try { sent = Api.sendPhoto({ chat_id: CID, photo: qrSrc, parse_mode: "HTML", caption: cap, reply_markup: JSON.stringify({ inline_keyboard: noUrlRows(gwKb(info.gid, info.checkout)) }) }); }
    catch (e2) { gwNote("qr send", "send", e2.message); gwErr(info.mid, "could not send QR image"); return; }
  }
  gwOrderSave(info.gid, { uid: UID, amount: num(info.amt, 0), ourId: String(info.ourId || ""), checkout: info.checkout || "", t: Date.now(), status: "pending", photo_mid: msgIdOf(sent) });
  if (info.mid) { try { Api.deleteMessage({ chat_id: CID, message_id: info.mid }); } catch (e) {} }
}
// Send the gateway checkout_url itself (no QR image) with I have paid / Cancel buttons
function gwSendLink(info) {
  var cap = bagEmoji() + " <b>Add Balance — " + money(info.amt) + "</b>\n\n" +
    "Tap <b>Open Payment Page</b> below to pay <b>" + money(info.amt) + "</b>.\n\n" +
    "Your balance updates <b>automatically</b> once payment is confirmed.\n\n" +
    "⏰ This link expires in <b>5 minutes</b> if payment isn't completed.";
  var sent = null;
  try { sent = Api.sendMessage({ chat_id: CID, text: cap, parse_mode: "HTML", disable_web_page_preview: true, reply_markup: JSON.stringify({ inline_keyboard: gwKb(info.gid, info.checkout) }) }); }
  catch (e) { sent = { ok: false, err: e.message }; }
  if (failed(sent)) {
    try { sent = Api.sendMessage({ chat_id: CID, text: cap, parse_mode: "HTML", disable_web_page_preview: true, reply_markup: JSON.stringify({ inline_keyboard: noUrlRows(gwKb(info.gid, info.checkout)) }) }); }
    catch (e2) { gwNote("link send", "send", e2.message); gwErr(info.mid, "could not send payment link"); return; }
  }
  gwOrderSave(info.gid, { uid: UID, amount: num(info.amt, 0), ourId: String(info.ourId || ""), checkout: info.checkout || "", t: Date.now(), status: "pending", photo_mid: msgIdOf(sent) });
  if (info.mid) { try { Api.deleteMessage({ chat_id: CID, message_id: info.mid }); } catch (e) {} }
}
try {
  var a = String(params || "").trim().split(/\s+/);
  var act = a[0] || "", oid = a[1] ? String(a[1]) : "";

  // ---- async results from galumodzgateway (HTTP callbacks) ----
  if (act === "created") {
    var pend = User.getProperty("gw_pend") || {};
    var rc = gwParse(gwCt());
    if (!rc || rc.ok !== true || !rc.order_id) {
      gwNote("create", gwHs(), gwCt());
      gwErr(pend.mid, rc && rc.error ? String(rc.error) : String(Bot.getProperty("gw_last_error") || ""));
      return;
    }
    var gid = String(rc.order_id);
    var checkout = String(rc.checkout_url || "");
    var apiQr = String(rc.qr_url || rc.qr_image || rc.qr || "");
    var info = { gid: gid, checkout: checkout, amt: num(pend.amt, 0), mid: pend.mid || null, ourId: String(pend.ourId || "") };
    if (apiQr) { gwSendQr(info, apiQr); return; }
    // API gives no QR field: take the SAME QR image the gateway shows on its checkout page
    if (!checkout) { gwNote("create", "no qr", "no QR and no checkout_url in response"); gwErr(pend.mid, "gateway returned no QR"); return; }
    gwSendLink(info);
    return;
  }
  if (act === "page") {
    var qp = User.getProperty("gw_qrp") || {};
    var html = String(gwCt() || "");
    var found = "";
    var re = /<img[^>]+src=["']([^"']+)["']/gi, m;
    while ((m = re.exec(html)) !== null) {
      if (/qr/i.test(m[1])) { found = m[1]; break; }
    }
    if (found && found.indexOf("http") !== 0) {
      var base = String(qp.checkout || "").match(/^https?:\/\/[^\/]+/);
      found = (base ? base[0] : "") + (found.charAt(0) === "/" ? "" : "/") + found;
    }
    if (!found || found.indexOf("data:") === 0) {
      gwNote("qr page", gwHs(), "QR image not found on checkout page");
      gwErr(qp.mid, "QR image not found on checkout page");
      return;
    }
    gwSendQr(qp, found);
    return;
  }
  if (act === "pgerr") {
    var qe = User.getProperty("gw_qrp") || {};
    gwNote("qr page", gwHs(), gwCt());
    gwErr(qe.mid, "could not open checkout page (HTTP " + String(gwHs()) + ")");
    return;
  }
  if (act === "cerr") {
    var pe = User.getProperty("gw_pend") || {};
    gwNote("create", gwHs(), gwCt());
    gwErr(pe.mid, String(Bot.getProperty("gw_last_error") || ""));
    return;
  }
  if (act === "vres") {
    var cur = String(User.getProperty("gw_cur") || "");
    var o2 = gwOrderLoad(cur);
    if (!o2) return;
    var rv = gwParse(gwCt());
    if (!rv || rv.ok !== true) {
      gwNote("verify", gwHs(), gwCt());
      gwSend("⚠️ Could not verify payment right now. Please try again.", gwRetryKb(cur, o2.checkout));
      return;
    }
    var vst = String(rv.status || "").toLowerCase();
    if (vst === "success" && rv.paid === true) {
      if (o2.status === "credited") return;
      if (Math.abs(num(rv.amount, 0) - num(o2.amount, 0)) > 0.001) {
        gwNote("verify", "amount mismatch", "paid " + rv.amount + " expected " + o2.amount);
        gwSend("⚠️ Paid amount does not match. Please contact support with your Order ID: <code>" + esc(cur) + "</code>", []);
        return;
      }
      o2.status = "credited"; gwOrderSave(cur, o2);   // mark first: no double credit
      var uc = loadUser(UID) || newUser(UID);
      uc.bal = r2(num(uc.bal, 0) + num(o2.amount, 0));
      if (!Array.isArray(uc.topups)) uc.topups = [];
      uc.topups.push({ t: Date.now(), amt: num(o2.amount, 0), oid: cur });
      if (uc.topups.length > 100) uc.topups = uc.topups.slice(-100);
      saveUser(uc);
      inc("st_topups", num(o2.amount, 0));
      sendTo(OWNER, "💰 <b>Auto top-up</b>\n👤 " + esc(uc.name) + " (<code>" + uc.id + "</code>)\n💵 " + money(o2.amount) + "\n🧾 Order: <code>" + esc(cur) + "</code>" + (rv.reference ? "\n🔖 Ref: <code>" + esc(rv.reference) + "</code>" : ""));
      gwSend(tgEmo("5980930633298350051", "✅") + " <b>Payment Successful!</b>\n\n" +
        tgEmo("5255981634527704754", "💰") + " Added: <b>" + money(o2.amount) + "</b>\n" +
        tgEmo("5409380072291316349", "🧾") + " Order ID: <code>" + esc(cur) + "</code>\n" +
        tgEmo("6328047923066053296", "🌑") + " Wallet balance: <b>" + money(uc.bal) + "</b>", [
        [B("Shop Now", "/buy", "danger")],
        [B("Menu", "/back", "primary", ICON_BACK)]
      ]);
      return;
    }
    if (vst === "expired") {
      o2.status = "expired"; gwOrderSave(cur, o2);
      gwSend("⌛ <b>QR Expired</b>\n\nTap <b>Add Balance</b> to generate a new QR.", [
        [B("Add Balance", "/addfund", "success", ICON_BAG)],
        [B("Back", "/back", "primary", ICON_BACK)]
      ]);
      return;
    }
    var cbq = String(User.getProperty("gw_cbq") || "");
    if (cbq) {
      try { Api.answerCallbackQuery({ callback_query_id: cbq, text: "Your Payment Not Received ❌", show_alert: true }); } catch (e) {}
    } else {
      gwSend("❌ <b>Your Payment Not Received</b>\n\nComplete the payment on the QR, then tap <b>✅ I have paid</b> again.", gwKb(cur, o2.checkout));
    }
    return;
  }
  if (act === "verr") {
    var cur2 = String(User.getProperty("gw_cur") || "");
    gwNote("verify", gwHs(), gwCt());
    var o3 = gwOrderLoad(cur2);
    gwSend("⚠️ Could not verify payment right now. Please try again.", gwRetryKb(cur2, o3 ? o3.checkout : ""));
    return;
  }

  // ---- button taps ----
  var o = oid ? gwOrderLoad(oid) : null;
  if (!o || String(o.uid) !== UID) { fail("❌ Payment not found."); return; }

  if (act === "cancel") {
    if (o.status === "credited") { ack("✅ Already paid and credited."); return; }
    o.status = "cancelled"; gwOrderSave(oid, o);
    show("❌ <b>Payment cancelled.</b>", [
      [B("Add Balance", "/addfund", "success", ICON_BAG)],
      [B("Back", "/back", "primary", ICON_BACK)]
    ]);
    return;
  }

  if (act === "paid") {
    if (o.status === "credited") { ack("✅ Already credited to your wallet."); return; }
    if (o.status === "cancelled") { ack("This payment was cancelled.", true); return; }
    if (o.status === "expired" || Date.now() - Number(o.t) > GW_EXPIRY_MS) {
      o.status = "expired"; gwOrderSave(oid, o);
      show("⌛ <b>QR Expired</b>\n\nThis payment QR was valid for 5 minutes and has expired.\nTap <b>Add Balance</b> to generate a new QR.", [
        [B("Add Balance", "/addfund", "success", ICON_BAG)],
        [B("Back", "/back", "primary", ICON_BACK)]
      ]);
      return;
    }
    User.setProperty("gw_cur", oid, "string");
    User.setProperty("gw_cbq", String(qid() || ""), "string");
    ack("Checking payment...");
    try {
      HTTP.post({
        url: CFG("gw_verify_url", GW_VERIFY_DEFAULT),
        headers: gwHeaders(),
        body: { action: "verify", api_key: CFG("gw_api_key", ""), order_id: oid },
        success: "/adpay vres",
        error: "/adpay verr"
      });
    } catch (e) {
      gwNote("verify", "send", e.message);
      gwSend("⚠️ Could not verify payment right now. Please try again.", gwRetryKb(oid, o.checkout));
    }
    return;
  }

  fail("❌ Unknown action.");
} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}
