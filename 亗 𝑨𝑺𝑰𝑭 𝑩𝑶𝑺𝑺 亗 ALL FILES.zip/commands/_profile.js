/**#command
name: /profile
answer:
keyboard:
parse_mode: markdown
aliases:
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// ================= SHARED HELPERS (auto-included in every command) =================
function CFG(k, d) { var v = Bot.getProperty(k); return (v === null || typeof v === "undefined" || v === "") ? d : v; }
function num(v, d) { var n = Number(v); return isFinite(n) ? n : d; }
function r2(n) { return Math.round(num(n, 0) * 100) / 100; }
function esc(s) { return String(s === null || typeof s === "undefined" ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
function money(n) { return "₹" + r2(n).toFixed(2); }
function tgE(id, fb) { return "<tg-emoji emoji-id=\"" + id + "\">" + fb + "</tg-emoji>"; }
function fmtDate(t) { if (!t) return "-"; return new Date(Number(t) + 19800000).toISOString().slice(0, 16).replace("T", " "); }

var OWNER = String(CFG("owner_id", "2049656553"));
var UID = String(user.telegramid);
var CID = chat.chatid;
var IS_NEW = false;

function isAdmin(id) { id = String(typeof id === "undefined" ? UID : id); return id === OWNER || !!Bot.getProperty("co_admin_" + id); }
function displayName() { var n = String((user.first_name || "") + " " + (user.last_name || "")).trim(); return n || user.username || "User"; }

// ---------- users ----------
function newUser(id) {
  return { id: String(id), name: displayName(), username: user.username || "", joined: Date.now(), bal: 0, spent: 0,
    order_count: 0, orders: [], topups: [], ref_by: null, ref_paid: false, refs: 0, ref_earn: 0, last_daily: 0, daily_total: 0 };
}
function loadUser(id) { var u = Bot.getProperty("u_" + id); return (u && typeof u === "object") ? u : null; }
function saveUser(u) { Bot.setProperty("u_" + u.id, u, "json"); }
function ensureUser() {
  var u = loadUser(UID);
  if (!u) {
    u = newUser(UID); IS_NEW = true;
    var list = Bot.getProperty("users");
    if (!Array.isArray(list)) list = [];
    list.push(UID);
    Bot.setProperty("users", list, "json");
  } else {
    u.name = displayName(); u.username = user.username || "";
  }
  saveUser(u);
  return u;
}

// ---------- conversation state ----------
function getState() { var s = User.getProperty("st"); return (s && typeof s === "object") ? s : null; }
function setState(o) { User.setProperty("st", o, "json"); }
function clearState() { User.setProperty("st", "", "string"); }

// ---------- products ----------
function products() { var p = Bot.getProperty("products"); return Array.isArray(p) ? p : []; }
function saveProducts(p) { Bot.setProperty("products", p, "json"); }
function stockOf(prod) { var n = 0; if (prod && prod.plans) for (var i = 0; i < prod.plans.length; i++) n += (prod.plans[i].keys || []).length; return n; }
function discPct() { return 0; }
function finalPrice(price, u) { return r2(num(price, 0)); }
function inc(k, by) { Bot.setProperty(k, String(r2(num(Bot.getProperty(k), 0) + by)), "string"); }

function linkOf(v) {
  v = String(v || "").trim(); if (!v) return "";
  if (/^https?:\/\//i.test(v)) return v;
  if (/^t\.me\//i.test(v)) return "https://" + v;
  return "https://t.me/" + v.replace(/^@/, "");
}

// ---------- telegram helpers ----------
// NOTE: Button text mein HTML/premium emoji support nahi hota.
// Isliye B() mein plain emoji fallback pass karna zaroori hai.
function B(text, data, style, icon) { var b = { text: text, callback_data: data }; if (style) b.style = style; if (icon) b.icon_custom_emoji_id = String(icon); return b; }
function Ub(text, url, style) { var b = { text: text, url: url }; if (style) b.style = style; return b; }
function qid() { if (!request) return null; return request.id || (request.callback_query && request.callback_query.id) || null; }
function isCb() { return !!(request && request.message && request.message.message_id && qid()); }
function ack(text, alert) {
  var q = qid(); if (!q) return;
  try { var o = { callback_query_id: String(q) }; if (text) { o.text = text; o.show_alert = !!alert; } Api.answerCallbackQuery(o); } catch (e) {}
}
function fail(text) { if (qid()) ack(text, true); else Api.sendMessage({ chat_id: CID, text: text }); }
function sendTo(id, text, rows) {
  var o = { chat_id: id, text: text, parse_mode: "HTML", disable_web_page_preview: true };
  if (rows) o.reply_markup = JSON.stringify({ inline_keyboard: rows });
  try { Api.sendMessage(o); } catch (e) {}
}
function show(text, rows) {
  var markup = JSON.stringify({ inline_keyboard: rows || [] });
  ack();
  if (isCb()) {
    var m = request.message;
    if (m.photo || m.video || m.document) {
      try { Api.deleteMessage({ chat_id: CID, message_id: m.message_id }); } catch (e) {}
      Api.sendMessage({ chat_id: CID, text: text, parse_mode: "HTML", disable_web_page_preview: true, reply_markup: markup });
    } else {
      Api.editMessageText({ chat_id: CID, message_id: m.message_id, text: text, parse_mode: "HTML", disable_web_page_preview: true, reply_markup: markup });
    }
  } else {
    Api.sendMessage({ chat_id: CID, text: text, parse_mode: "HTML", disable_web_page_preview: true, reply_markup: markup });
  }
}

// ================= PREMIUM EMOJI HELPERS =================
// Message body ke liye premium emoji (HTML tag)
function pe(id, fallback) {
  return '<tg-emoji emoji-id="' + String(id) + '">' + (fallback || "⭐") + '</tg-emoji>';
}
// Button ke liye: premium emoji ID ka actual unicode fallback char use hota hai
// (kyunki button text HTML parse nahi karta)
function peBtn(fallbackChar) {
  return fallbackChar || "⭐";
}

var BACK = [B("Back", "/back", "primary", "5240177683886784793")];
// ---------- global Maintenance Mode (bot off for all users; admins bypass) ----------
if (CFG("maint_mode", "") === "1" && !isAdmin()) {
  try {
    var mmLink = linkOf(CFG("update_link", ""));
    show("🛠 <b>Bot Under Maintenance</b>\n\nThe bot is currently under maintenance. Please check back later — sorry for the inconvenience!",
      mmLink ? [[{ text: "Check Update", url: mmLink, style: "primary" }]] : []);
  } catch (e) {}
  return;
}


try {
  var u = ensureUser(); clearState();
  var oc = u.orders.length, tc = u.topups.length;

  // Premium emoji IDs (message body ke liye)
  var E_PROFILE  = pe("5256143829672672750", "👤");
  var E_ID       = pe("5812306661024469353", "🆔");
  var E_NAME     = pe("5193018401810822951", "📛");
  var E_JOINED   = pe("6194823951714099861", "📅");
  var E_BALANCE  = pe("6210859306602995217", "🌑");
  var E_ORDERS   = pe("6093562529978522804", "🛒");
  var E_SPENT    = pe("5233326571099534068", "💸");
  var E_REFER    = pe("5442939099906325301", "👥");

  // My Keys button ke liye premium emoji (button text — plain fallback)
  var BTN_KEYS = "My Keys"; // <-- yahan premium emoji direct nahi lagega, fallback hi rahega

  var text = E_PROFILE + " <b>My Profile</b>\n\n" +
    E_ID + " ID: <code>" + u.id + "</code>\n" +
    E_NAME + " Name: <b>" + esc(u.name) + "</b>\n" +
    (u.username ? tgE("5287226881655977659", "🔗") + " Username: @" + esc(u.username) + "\n" : "") +
    (!!Bot.getProperty("reseller_" + UID) ? "🏷 Account: <b>Reseller</b>\n" : "") +
    E_JOINED + " Joined: " + fmtDate(u.joined) + "\n\n" +
    E_BALANCE + " Balance: <b>" + money(u.bal) + "</b>\n" +
    E_ORDERS + " Orders: <b>" + (u.order_count || oc) + "</b>\n" +
    E_SPENT + " Total Spent: <b>" + money(u.spent) + "</b>\n" +
    E_REFER + " Referrals: <b>" + (u.refs || 0) + "</b>  (earned " + money(u.ref_earn || 0) + ")\n";

  var t = u.topups.slice(-3).reverse();
  if (t.length) {
    text += "\n💳 <b>Recent Top-ups</b>\n";
    for (var k = 0; k < t.length; k++) text += "• " + money(t[k].amount) + " — " + (t[k].status === "approved" ? "✅" : t[k].status === "rejected" ? "❌" : "⏳") + " " + t[k].status + "\n";
  }
  show(text, [
    [B(BTN_KEYS, "/hist orders", "success", "6005570495603282482")],
    BACK
  ]);
} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}